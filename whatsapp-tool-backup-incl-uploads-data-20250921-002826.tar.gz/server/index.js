// Force Cairo timezone for server-side localtime operations
process.env.TZ = 'Africa/Cairo';
import express from 'express';
import http from 'http';
import { Server as SocketIOServer } from 'socket.io';
import cors from 'cors';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import pino from 'pino';
import pretty from 'pino-pretty';
import mime from 'mime-types';
import qrcode from 'qrcode-terminal';
import wweb from 'whatsapp-web.js';
import { QueueManager } from './queue.js';
import { AutoReplyManager } from './autoreply.js';
import { AgentManager } from './agent.js';
import archiver from 'archiver';
import unzipper from 'unzipper';
const { Client, LocalAuth, MessageMedia } = wweb;

// ES module equivalent of __dirname
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const logger = pino(pretty({ translateTime: 'SYS:standard', ignore: 'pid,hostname' }));

const app = express();
const server = http.createServer(app);
const io = new SocketIOServer(server, { cors: { origin: '*', methods: ['GET', 'POST'] } });

const PORT = process.env.PORT || 3000;
const UPLOAD_DIR = path.resolve('./uploads');
const DATA_DIR = path.resolve('./data');
// Resolve an installed Chrome/Chromium executable for Puppeteer to use
function resolveChromeExecutable() {
  try {
    const fromEnv = process.env.CHROME_PATH;
    if (fromEnv && fs.existsSync(fromEnv)) return fromEnv;
  } catch {}
  const candidates = [
    // macOS
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    '/Applications/Google Chrome Beta.app/Contents/MacOS/Google Chrome Beta',
    '/Applications/Google Chrome Canary.app/Contents/MacOS/Google Chrome Canary',
    // Linux
    '/usr/bin/google-chrome',
    '/usr/bin/chromium-browser',
    '/usr/bin/chromium',
    '/snap/bin/chromium',
    // Windows
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  ];
  for (const p of candidates) {
    try { if (fs.existsSync(p)) return p; } catch {}
  }
  return null;
}
const CHROME_EXEC_PATH = resolveChromeExecutable();
if (CHROME_EXEC_PATH) {
  try { logger.info({ chromePath: CHROME_EXEC_PATH }, 'Using system Chrome for Puppeteer'); } catch {}
} else {
  try { logger.warn('No system Chrome found. Puppeteer will try its bundled Chromium if available.'); } catch {}
}
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
const TPL_FILE = path.join(DATA_DIR, 'templates.json');
if (!fs.existsSync(TPL_FILE)) fs.writeFileSync(TPL_FILE, '[]');
const DB_FILE = path.join(DATA_DIR, 'queue.db');
const queue = new QueueManager(DB_FILE);
const AR_DB = path.join(DATA_DIR, 'autoreply.db');
const autoReply = new AutoReplyManager(AR_DB);
const AGENT_DB = path.join(DATA_DIR, 'agent.db');
const agentMgr = new AgentManager(AGENT_DB);

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use('/public', express.static(path.join(__dirname, '../client/public')));
app.use('/uploads', express.static(UPLOAD_DIR));

// Ensure AI Agent is enabled by default, preserving existing prompt/API key
try {
  const cur = agentMgr.getSettings();
  if (!cur.enabled) agentMgr.updateSettings({ enabled: true, prompt: cur.prompt });
} catch {}

// Admin page route
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/public/admin.html'));
});

// Agent page route
app.get('/agent', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/public/agent.html'));
});

// KB Quality page route
app.get('/kb-quality', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/public/kb-quality.html'));
});
// Moderator dashboard route
app.get('/moderator', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/public/moderator.html'));
});
// Templates store
function loadTemplates() {
  try {
    const raw = fs.readFileSync(TPL_FILE, 'utf8');
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}
function saveTemplates(list) {
  try { fs.writeFileSync(TPL_FILE, JSON.stringify(list, null, 2)); } catch {}
}


// Multer storage
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname);
    const base = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9_-]/g, '_');
    const name = `${Date.now()}_${base}${ext}`;
    cb(null, name);
  },
});
const upload = multer({ storage });

// Multi-session management
const sessions = new Map(); // id -> { client, isReady, currentCampaign }
// Human takeover overrides: key => `${sessionId}::${chatId}` -> { until: msEpoch, mode: 'all' | 'aiOnly' }
const humanOverrides = new Map();

function overrideKey(sessionId, chatId) { return `${sessionId}::${chatId}`; }
function setHumanOverride(sessionId, chatId, minutes = 15, mode = 'all') {
  try {
    if (!sessionId || !chatId) return;
    const until = Date.now() + Math.max(1, Number(minutes)) * 60 * 1000;
    humanOverrides.set(overrideKey(sessionId, chatId), { until, mode });
  } catch {}
}
function clearHumanOverride(sessionId, chatId) {
  try { humanOverrides.delete(overrideKey(sessionId, chatId)); } catch {}
}
function getHumanOverride(sessionId, chatId) {
  try {
    const k = overrideKey(sessionId, chatId);
    const v = humanOverrides.get(k);
    if (!v) return null;
    if (Date.now() > v.until) { humanOverrides.delete(k); return null; }
    return v;
  } catch { return null; }
}
const workers = new Map(); // id -> { running, paused, messagesSinceThrottle, consecutiveFailures }
const extractResults = new Map(); // id -> { createdAt, sessionId, rows: Array<{phone, type, source, chat_title, chat_id, name}>, unique: number }

function getRoom(sessionId) {
  return `session:${sessionId}`;
}

function createClient(sessionId) {
  const puppeteerOptions = {
    headless: true,
    timeout: 60000,
    protocolTimeout: 120000,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-accelerated-2d-canvas',
      '--disable-gpu',
      '--no-first-run',
      '--no-default-browser-check',
      '--disable-features=TranslateUI,site-per-process',
      '--disable-extensions',
      '--password-store=basic',
      '--disable-background-timer-throttling',
      '--disable-backgrounding-occluded-windows',
      '--disable-renderer-backgrounding',
      '--window-size=1280,800',
      '--remote-debugging-port=0',
    ],
  };
  if (CHROME_EXEC_PATH) {
    puppeteerOptions.executablePath = CHROME_EXEC_PATH;
  }
  const client = new Client({
    authStrategy: new LocalAuth({ clientId: `whats-tool-${sessionId}` }),
    puppeteer: puppeteerOptions,
  });

  const state = { client, isReady: false, currentCampaign: null, lastQr: null, lastQrAt: 0, _reconnecting: false, autoReconnectFailures: 0 };
  sessions.set(sessionId, state);

  client.on('qr', (qr) => {
    logger.info({ sessionId }, 'QR received. Scan to login.');
    try { qrcode.generate(qr, { small: true }); } catch {}
    const now = Date.now();
    // Dedupe/throttle QR emissions to avoid spamming clients
    if (state.lastQr === qr && (now - state.lastQrAt) < 2000) {
      return;
    }
    state.lastQr = qr;
    state.lastQrAt = now;
    io.to(getRoom(sessionId)).emit('wa_qr', { sessionId, qr });
  });

  client.on('ready', async () => {
    state.isReady = true;
    state.lastQr = null;
    state.lastQrAt = 0;
    state.autoReconnectFailures = 0;
    const { number, pushName, profilePicUrl } = await getProfileInfo(client);
    logger.info({ sessionId, number }, 'WhatsApp client is ready.');
    io.to(getRoom(sessionId)).emit('wa_ready', { sessionId, ready: true, number, pushName });
    if (profilePicUrl) io.to(getRoom(sessionId)).emit('wa_profile', { sessionId, profilePicUrl, number, pushName });
  });

  client.on('authenticated', () => {
    logger.info({ sessionId }, 'Authenticated.');
    io.to(getRoom(sessionId)).emit('wa_auth', { sessionId, status: 'authenticated' });
  });

  client.on('auth_failure', (m) => {
    state.isReady = false;
    logger.error({ sessionId, m }, 'Authentication failure');
    io.to(getRoom(sessionId)).emit('wa_auth', { sessionId, status: 'failure', message: String(m || '') });
    // Trigger a controlled reconnect after auth failure
    (async () => {
      if (state._reconnecting) return;
      state._reconnecting = true;
      try {
        try { await state.client.destroy(); } catch {}
        await sleep(300);
        try {
          const lockPath = path.join(__dirname, '.wwebjs_auth', `session-whats-tool-${sessionId}`, 'SingletonLock');
          await fs.promises.unlink(lockPath).catch(() => {});
        } catch {}
        const newState = createClient(sessionId);
        await newState.client.initialize();
      } catch (e) {
        logger.error({ sessionId, error: String(e) }, 'Auto-reconnect after auth failure failed');
      } finally {
        state._reconnecting = false;
      }
    })();
  });

  // Additional connection lifecycle events for richer client UX
  client.on('loading_screen', (percent, message) => {
    try {
      io.to(getRoom(sessionId)).emit('wa_loading', { sessionId, percent, message });
    } catch {}
  });

  client.on('change_state', (stateStr) => {
    logger.info({ sessionId, state: stateStr }, 'Client state changed');
    try {
      io.to(getRoom(sessionId)).emit('wa_state', { sessionId, state: stateStr });
    } catch {}
  });

  client.on('disconnected', (reason) => {
    state.isReady = false;
    logger.warn({ sessionId, reason }, 'Client disconnected');
    io.to(getRoom(sessionId)).emit('wa_disconnected', { sessionId, reason });
    
    // Stop any running campaigns when disconnected
    if (state.currentCampaign) {
      state.currentCampaign = null;
      io.to(getRoom(sessionId)).emit('campaign_status', { sessionId, status: 'disconnected' });
    }
    
    // Exponential backoff reconnect with singleton lock cleanup
    (async () => {
      let attempt = 0;
      while (!state.isReady && attempt < 5) {
        const delay = Math.min(30000, 2000 * Math.pow(2, attempt));
        await sleep(delay);
        try {
          // Cleanup lock
          try {
            const lockPath = path.join(__dirname, '.wwebjs_auth', `session-whats-tool-${sessionId}`, 'SingletonLock');
            await fs.promises.unlink(lockPath).catch(() => {});
          } catch {}
          logger.info({ sessionId, attempt }, 'Reconnecting client...');
          await client.initialize();
        } catch (err) {
          logger.error({ sessionId, error: String(err), attempt }, 'Reconnect attempt failed');
          // If browser disconnected, recreate fresh client instance
          if (String(err || '').includes('browser has disconnected')) {
            try { await client.destroy(); } catch {}
            const newState = createClient(sessionId);
            client = newState.client;
          }
        }
        attempt += 1;
      }
    })();
  });

  // Auto-reply on new messages
  client.on('message', async (msg) => {
    try {
      // Ignore own messages
      if (msg.fromMe) {
        // Owner/agent wrote in this chat; activate takeover
        try { setHumanOverride(sessionId, msg.to || msg.from, 15, 'all'); } catch {}
        return;
      }
      const text = (msg.body || '').trim();
      const chatId = msg.from;
      // Emit realtime event for incoming message so moderators can see live chat
      try {
        io.to(getRoom(sessionId)).emit('chat_message', {
          sessionId,
          chatId: chatId,
          message: {
            id: msg?.id?._serialized || null,
            body: msg.body || '',
            from: msg.from,
            to: msg.to,
            fromMe: false,
            timestamp: msg.timestamp || Math.floor(Date.now() / 1000),
            type: msg.type,
            hasMedia: !!msg.hasMedia
          }
        });
      } catch {}
      // Basic typing indicator: show typing for 2s before message received
      try { io.to(getRoom(sessionId)).emit('typing', { sessionId, chatId, typing: true }); setTimeout(()=>{ try { io.to(getRoom(sessionId)).emit('typing', { sessionId, chatId, typing: false }); } catch {} }, 2000); } catch {}
      const takeover = getHumanOverride(sessionId, chatId);
      if (takeover && takeover.mode === 'all') {
        logger.info({ sessionId, chatId, mode: takeover.mode }, 'Human takeover active: suppressing automation');
        return;
      }
      
      // Check flow triggers first
      logger.info({ 
        sessionId, 
        messageBody: msg.body, 
        messageType: msg.type,
        fromMe: msg.fromMe,
        from: msg.from
      }, 'Processing incoming message');
      const flowHandled = await checkFlowTriggers(msg, sessionId);
      if (flowHandled) {
        logger.info({ sessionId, messageBody: msg.body }, 'Message handled by flow, skipping other handlers');
        return; // Exit early if flow handled the message
      }
      const rules = autoReply.enabledFor(sessionId);
      // Time window helper
      const parseMin = (t) => {
        if (!t) return null; const [h,m] = String(t).split(':').map(Number); if (Number.isNaN(h)||Number.isNaN(m)) return null; return h*60+m;
      };
      const nowMin = new Date().getHours()*60 + new Date().getMinutes();
      let handled = false;
      for (const r of rules) {
        const st = parseMin(r.window_start); const en = parseMin(r.window_end);
        if (st!=null && en!=null) {
          const inWin = st<=en ? (nowMin>=st && nowMin<=en) : (nowMin>=st || nowMin<=en);
          if (!inWin) continue;
        }
        let matched = false;
        const pat = r.pattern || '';
        switch (r.match_type) {
          case 'equals': matched = text.toLowerCase() === pat.toLowerCase(); break;
          case 'startsWith': matched = text.toLowerCase().startsWith(pat.toLowerCase()); break;
          case 'endsWith': matched = text.toLowerCase().endsWith(pat.toLowerCase()); break;
          case 'regex':
            try { const re = new RegExp(pat, 'i'); matched = re.test(text); } catch {}
            break;
          default: matched = text.toLowerCase().includes(pat.toLowerCase());
        }
        if (!matched) continue;

        // Send response
        const chatId = msg.from;
        if (r.media_path) {
          const absPath = path.isAbsolute(r.media_path) ? r.media_path : path.join(UPLOAD_DIR, r.media_path);
          if (fs.existsSync(absPath)) {
            const mimeType = mime.lookup(absPath) || 'application/octet-stream';
            const base64 = fs.readFileSync(absPath, { encoding: 'base64' });
            const filename = path.basename(absPath);
            const media = new MessageMedia(mimeType, base64, filename);
            await client.sendMessage(chatId, media, { caption: r.response || undefined });
          } else {
            await client.sendMessage(chatId, r.response || '');
          }
        } else {
          await client.sendMessage(chatId, r.response || '');
        }
        autoReply.incHit(r.id);
        handled = true; break; // first match wins
      }
      if (!handled) {
        // If human override is AI-only, skip AI but allow flows/autoreplies
        if (takeover && (takeover.mode === 'aiOnly' || takeover.mode === 'AI' || takeover.mode === 'ai')) {
          logger.info({ sessionId, chatId, mode: takeover.mode }, 'Human takeover (AI only): skipping AI reply');
          return;
        }
        // fallback to AI Agent if enabled; gather last 25 messages for context
        let history = [];
        try {
          const chat = await msg.getChat();
          if (chat && typeof chat.fetchMessages === 'function') {
            const msgs = await chat.fetchMessages({ limit: 25 });
            history = msgs
              .filter(m => typeof m.body === 'string' && m.body.trim().length)
              .map(m => ({ fromMe: m.fromMe, body: m.body.trim() }));
          }
        } catch {}
        const reply = await agentMgr.generateReply(text, { sessionId, history });
        if (reply) {
          try { await client.sendMessage(msg.from, reply); } catch {}
        }
      }
    } catch (err) {
      logger.error({ sessionId, err: String(err) }, 'Auto-reply error');
    }
  });

  // Outgoing messages created by this client (from WhatsApp Web or sendMessage)
  client.on('message_create', async (msg) => {
    try {
      // Only emit for messages sent by us
      if (!msg.fromMe) return;
      const chatId = msg.to || msg.from;
      io.to(getRoom(sessionId)).emit('chat_message', {
        sessionId,
        chatId: chatId,
        message: {
          id: msg?.id?._serialized || null,
          body: msg.body || '',
          from: msg.from,
          to: msg.to,
          fromMe: true,
          timestamp: msg.timestamp || Math.floor(Date.now() / 1000),
          type: msg.type,
          hasMedia: !!msg.hasMedia
        }
      });
    } catch (e) {
      logger.warn({ sessionId, error: String(e) }, 'Failed to emit message_create socket event');
    }
  });

  // Read receipts (ack) updates for messages
  client.on('message_ack', (msg, ack) => {
    try {
      const chatId = msg.to || msg.from;
      io.to(getRoom(sessionId)).emit('message_ack', {
        sessionId,
        chatId,
        id: msg?.id?._serialized || null,
        ack
      });
    } catch (e) {
      logger.warn({ sessionId, error: String(e) }, 'Failed to emit message_ack');
    }
  });

  return state;
}

function ensureSession(sessionId) {
  return sessions.get(sessionId) || createClient(sessionId);
}

// Attempt a controlled reconnect for a given session
async function triggerReconnect(sessionId) {
  const state = sessions.get(sessionId);
  if (!state) return { started: false, reason: 'no_state' };
  if (state._reconnecting) return { started: false, reason: 'already_reconnecting' };
  state._reconnecting = true;
  try {
    try { await state.client.destroy(); } catch {}
    try {
      const lockPath = path.join(__dirname, '.wwebjs_auth', `session-whats-tool-${sessionId}`, 'SingletonLock');
      await fs.promises.unlink(lockPath).catch(() => {});
    } catch {}
    const newState = createClient(sessionId);
    await newState.client.initialize();
    return { started: true };
  } catch (e) {
    logger.error({ sessionId, error: String(e) }, 'triggerReconnect failed');
    return { started: false, error: String(e) };
  } finally {
    state._reconnecting = false;
  }
}

function safeGetClientNumber(client) {
  try {
    const wid = client?.info?.wid;
    if (!wid) return null;
    if (typeof wid.user === 'string' && wid.user) return wid.user;
    const ser = wid._serialized || '';
    if (ser) return String(ser).replace(/@c\.us$/, '');
  } catch {}
  return null;
}

async function getProfileInfo(client) {
  const number = safeGetClientNumber(client);
  const pushName = client?.info?.pushname || null;
  let profilePicUrl = null;
  try {
    const wid = client?.info?.wid?._serialized;
    if (wid) profilePicUrl = await client.getProfilePicUrl(wid);
  } catch {}
  return { number, pushName, profilePicUrl };
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// WhatsApp number validation function
async function validateWhatsAppNumber(state, phone) {
  try {
    const chatId = phone.includes('@c.us') ? phone : `${phone.replace(/[^0-9]/g, '')}@c.us`;
    
    // Check if session is ready
    if (!state.isReady || !state.client || state.client.info === null) {
      return { valid: false, error: 'WhatsApp session not ready' };
    }
    
    // Try to get chat info to validate the number
    try {
      const chat = await state.client.getChatById(chatId);
      if (chat && chat.id) {
        return { valid: true, chatId, chat };
      }
    } catch (chatError) {
      // If chat doesn't exist, try to check if number is registered
      try {
        // Try to get number info
        const numberId = chatId.replace('@c.us', '');
        const numberInfo = await state.client.getNumberId(numberId);
        if (numberInfo) {
          return { valid: true, chatId, numberInfo };
        }
      } catch (numberError) {
        // Number is not registered on WhatsApp
        return { valid: false, error: 'Number not registered on WhatsApp' };
      }
    }
    
    return { valid: false, error: 'Unable to validate number' };
  } catch (error) {
    return { valid: false, error: `Validation error: ${error.message}` };
  }
}

async function sendItem(state, item) {
  const { phone, message, mediaPath, caption } = item; // phone in international format without '+'
  const chatId = phone.includes('@c.us') ? phone : `${phone.replace(/[^0-9]/g, '')}@c.us`;

  // Check if session is still ready before sending
  if (!state.isReady) {
    throw new Error('WhatsApp session is not ready. Please check your connection and try again.');
  }

  // Check if client is still connected
  if (!state.client || state.client.info === null) {
    throw new Error('WhatsApp client is disconnected. Please reconnect your session.');
  }

  try {
    if (mediaPath) {
      const absPath = path.isAbsolute(mediaPath) ? mediaPath : path.join(UPLOAD_DIR, mediaPath);
      const exists = fs.existsSync(absPath);
      if (!exists) throw new Error(`Media not found: ${absPath}`);
      const mimeType = mime.lookup(absPath) || 'application/octet-stream';
      const base64 = fs.readFileSync(absPath, { encoding: 'base64' });
      const filename = path.basename(absPath);
      const media = new MessageMedia(mimeType, base64, filename);
      const usedCaption = typeof caption === 'string' && caption.length ? caption : (message || undefined);
      await state.client.sendMessage(chatId, media, { caption: usedCaption });
    } else {
      await state.client.sendMessage(chatId, message || '');
    }
  } catch (error) {
    const errorMsg = String(error?.message || error);
    
    // Handle specific session closed errors
    if (errorMsg.includes('Session closed') || 
        errorMsg.includes('Protocol error') || 
        errorMsg.includes('Runtime.callFunctionOn') ||
        errorMsg.includes('Target closed') ||
        errorMsg.includes('Connection closed')) {
      
      // Mark session as not ready
      state.isReady = false;
      
      // Try to reinitialize the client
      try {
        logger.warn({ sessionId: state.client.info?.wid?.user }, 'Session closed, attempting to reconnect...');
        await state.client.initialize();
      } catch (reconnectError) {
        logger.error({ sessionId: state.client.info?.wid?.user, error: String(reconnectError) }, 'Failed to reconnect session');
      }
      
      throw new Error('WhatsApp session was closed. Please check your WhatsApp Web connection and try again.');
    }
    
    // Handle other common errors
    if (errorMsg.includes('Number not found') || errorMsg.includes('not registered')) {
      throw new Error('Phone number is not registered on WhatsApp');
    }
    
    if (errorMsg.includes('Rate limit') || errorMsg.includes('Too many messages')) {
      throw new Error('Rate limit exceeded. Please wait before sending more messages.');
    }
    
    // Re-throw the original error if it's not a session issue
    throw error;
  }
}

function parseTimeStringToMinutes(timeStr) {
  if (!timeStr) return null;
  const [h, m] = String(timeStr).split(':').map(Number);
  if (Number.isNaN(h) || Number.isNaN(m)) return null;
  return h * 60 + m;
}

function inWindow(now, startMin, endMin) {
  if (startMin == null || endMin == null) return true; // no window
  const minutes = now.getHours() * 60 + now.getMinutes();
  if (startMin <= endMin) return minutes >= startMin && minutes <= endMin;
  // window wraps past midnight
  return minutes >= startMin || minutes <= endMin;
}

async function waitUntilWindow(now, startMin) {
  const minutes = now.getHours() * 60 + now.getMinutes();
  let waitMinutes = 0;
  if (startMin == null) return;
  if (minutes <= startMin) {
    waitMinutes = startMin - minutes;
  } else {
    waitMinutes = 24 * 60 - minutes + startMin; // next day
  }
  await sleep(waitMinutes * 60 * 1000);
}

function jitteredDelay(baseMs, jitterPct) {
  const pct = Math.max(0, Math.min(100, Number(jitterPct) || 0));
  if (!pct) return baseMs;
  const delta = baseMs * (pct / 100);
  const min = Math.max(0, baseMs - delta);
  const max = baseMs + delta;
  return Math.floor(min + Math.random() * (max - min));
}

function pad2(n) { return String(n).padStart(2, '0'); }
function formatDate(d) { return `${d.getFullYear()}-${pad2(d.getMonth()+1)}-${pad2(d.getDate())}`; }
function formatTime(d) { return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`; }
function formatDateTime(d) { return `${formatDate(d)} ${formatTime(d)}`; }
function replaceSystemVars(text) {
  if (!text) return text;
  let out = String(text);
  const now = new Date();
  
  // Basic date/time variables
  out = out.replace(/\{date\}/g, formatDate(now));
  out = out.replace(/\{time\}/g, formatTime(now));
  out = out.replace(/\{datetime\}/g, formatDateTime(now));
  
  // Enhanced date variables with formats
  out = out.replace(/\{date:([^}]+)\}/g, (_m, format) => {
    try {
      switch (format.toLowerCase()) {
        case 'iso': return now.toISOString().split('T')[0];
        case 'us': return now.toLocaleDateString('en-US');
        case 'eu': return now.toLocaleDateString('en-GB');
        case 'short': return now.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
        case 'long': return now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
        case 'ddmmyyyy': return `${pad2(now.getDate())}/${pad2(now.getMonth()+1)}/${now.getFullYear()}`;
        case 'mmddyyyy': return `${pad2(now.getMonth()+1)}/${pad2(now.getDate())}/${now.getFullYear()}`;
        default: return formatDate(now);
      }
    } catch (e) {
      return formatDate(now);
    }
  });
  
  // Enhanced time variables with formats
  out = out.replace(/\{time:([^}]+)\}/g, (_m, format) => {
    try {
      switch (format.toLowerCase()) {
        case '12': return now.toLocaleTimeString('en-US', { hour12: true });
        case '24': return now.toLocaleTimeString('en-US', { hour12: false });
        case 'short': return now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
        case 'long': return now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        case 'hms': return `${pad2(now.getHours())}:${pad2(now.getMinutes())}:${pad2(now.getSeconds())}`;
        default: return formatTime(now);
      }
    } catch (e) {
      return formatTime(now);
    }
  });
  
  // Enhanced datetime variables
  out = out.replace(/\{datetime:([^}]+)\}/g, (_m, format) => {
    try {
      switch (format.toLowerCase()) {
        case 'iso': return now.toISOString();
        case 'short': return now.toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' });
        case 'long': return now.toLocaleString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' });
        case 'full': return now.toLocaleString();
        default: return formatDateTime(now);
      }
    } catch (e) {
      return formatDateTime(now);
    }
  });
  
  // Individual date components
  out = out.replace(/\{year\}/g, now.getFullYear().toString());
  out = out.replace(/\{month\}/g, (now.getMonth() + 1).toString());
  out = out.replace(/\{day\}/g, now.getDate().toString());
  out = out.replace(/\{hour\}/g, now.getHours().toString());
  out = out.replace(/\{minute\}/g, now.getMinutes().toString());
  out = out.replace(/\{second\}/g, now.getSeconds().toString());
  
  // Day of week
  out = out.replace(/\{weekday\}/g, now.toLocaleDateString('en-US', { weekday: 'long' }));
  out = out.replace(/\{weekday:short\}/g, now.toLocaleDateString('en-US', { weekday: 'short' }));
  
  // Month name
  out = out.replace(/\{monthname\}/g, now.toLocaleDateString('en-US', { month: 'long' }));
  out = out.replace(/\{monthname:short\}/g, now.toLocaleDateString('en-US', { month: 'short' }));
  
  // Random number variables
  out = out.replace(/\{rand(?::(\d+)-(\d+))?\}/g, (_m, a, b) => {
    let min = 100000, max = 999999;
    if (a && b) { min = Number(a); max = Number(b); }
    if (Number.isNaN(min) || Number.isNaN(max) || max < min) { min = 0; max = 999999; }
    return String(Math.floor(min + Math.random() * (max - min + 1)));
  });
  
  return out;
}

async function runCampaignLoop(sessionId) {
  const state = sessions.get(sessionId);
  if (!state || !state.currentCampaign) return;
  const camp = state.currentCampaign;
  const { id, items, delayMs, startTime, window, retries, throttle, validateNumbers } = camp;
  const startMin = parseTimeStringToMinutes(window?.start);
  const endMin = parseTimeStringToMinutes(window?.end);

  io.to(getRoom(sessionId)).emit('campaign_status', { sessionId, id, status: 'running' });
  let success = 0;
  let failure = 0;

  // Wait until start time if specified
  if (startTime) {
    const target = new Date(startTime);
    const now = new Date();
    if (target > now) await sleep(target.getTime() - now.getTime());
  }

  for (let index = 0; index < items.length; index += 1) {
    const latest = sessions.get(sessionId);
    if (!latest || !latest.currentCampaign || latest.currentCampaign.id !== id) break; // cancelled or replaced
    const item = items[index];

    // Ensure we are inside sending window
    while (!inWindow(new Date(), startMin, endMin)) {
      await waitUntilWindow(new Date(), startMin);
    }

    let sent = false;
    let errorMsg = '';
    const maxRetries = Math.max(0, Number(retries?.maxRetries) || 0);
    const baseMs = Math.max(250, Number(retries?.baseMs) || 1000);
    const jitterPct = Number(retries?.jitterPct) || 0;

    // Validate WhatsApp number before sending (if enabled)
    if (validateNumbers !== false) {
      const validation = await validateWhatsAppNumber(state, item.phone);
      if (!validation.valid) {
        failure += 1;
        io.to(getRoom(sessionId)).emit('campaign_progress', {
          sessionId,
          id,
          index,
          phone: item.phone,
          status: 'failed',
          error: `Validation failed: ${validation.error}`,
        });
        continue; // Skip to next number
      }
    }

    for (let attempt = 0; attempt <= maxRetries; attempt += 1) {
      try {
        const enriched = { ...item };
        if (enriched.message) enriched.message = replaceSystemVars(enriched.message);
        if (enriched.caption) enriched.caption = replaceSystemVars(enriched.caption);
        await sendItem(state, enriched);
        sent = true;
        success += 1;
        io.to(getRoom(sessionId)).emit('campaign_progress', { sessionId, id, index, phone: item.phone, status: 'sent' });
        break;
      } catch (err) {
        errorMsg = String(err?.message || err);
        if (attempt < maxRetries) {
          const backoff = jitteredDelay(baseMs * Math.pow(2, attempt), jitterPct);
          await sleep(backoff);
          continue;
        }
      }
    }

    if (!sent) {
      failure += 1;
      io.to(getRoom(sessionId)).emit('campaign_progress', {
        sessionId,
        id,
        index,
        phone: item.phone,
        status: 'failed',
        error: errorMsg,
      });
    }

    if (index < items.length - 1) {
      // base per-message delay
      await sleep(delayMs);
      // throttle: sleep for X sec after Y messages
      const every = Math.max(0, Number(throttle?.messages) || 0);
      const restSec = Math.max(0, Number(throttle?.sleepSec) || 0);
      if (every > 0 && restSec > 0 && (index + 1) % every === 0) {
        await sleep(restSec * 1000);
      }
    }
  }
  io.to(getRoom(sessionId)).emit('campaign_status', { sessionId, id, status: 'finished' });
  state.currentCampaign = null;
  logger.info({ sessionId, id, success, failure }, 'Campaign finished');
}

// Worker: processes queued jobs per session with guardrails
const FAILURE_COOLDOWN_MS = 10 * 60 * 1000; // 10 minutes
const FAILURE_BURST_THRESHOLD = 10; // consecutive failures to trigger cooldown

async function startWorker(sessionId) {
  const existingWorker = workers.get(sessionId);
  if (existingWorker && existingWorker.running) return;
  
  const state = sessions.get(sessionId);
  if (!state) return;
  const worker = { running: true, paused: false, messagesSinceThrottle: 0, consecutiveFailures: 0 };
  workers.set(sessionId, worker);
  logger.info({ sessionId }, 'Worker started');

  const sendFromJob = async (job) => {
    // Build item compatible with sendItem
    const item = { phone: job.phone, message: job.message, caption: job.caption, mediaPath: job.media_path };
    
    // Validate WhatsApp number before sending
    const validation = await validateWhatsAppNumber(state, item.phone);
    if (!validation.valid) {
      io.to(getRoom(sessionId)).emit('campaign_progress', {
        sessionId,
        id: job.campaign_id,
        index: job.id,
        phone: job.phone,
        status: 'failed',
        error: `Validation failed: ${validation.error}`,
      });
      return; // Skip this job
    }
    
    const enriched = { ...item };
    if (enriched.message) enriched.message = replaceSystemVars(enriched.message);
    if (enriched.caption) enriched.caption = replaceSystemVars(enriched.caption);
    await sendItem(state, enriched);
    io.to(getRoom(sessionId)).emit('campaign_progress', { sessionId, id: job.campaign_id, index: job.id, phone: job.phone, status: 'sent' });
  };

  while (worker.running) {
    try {
      const sessionState = sessions.get(sessionId);
      if (!sessionState?.isReady) { 
        logger.debug({ sessionId }, 'Session not ready, waiting...');
        await sleep(1000); 
        continue; 
      }
      
      // Check if client is still connected
      if (!sessionState.client || sessionState.client.info === null) {
        logger.warn({ sessionId }, 'Client connection lost, waiting for reconnect...');
        await sleep(2000);
        continue;
      }
      
      if (worker.paused) { await sleep(500); continue; }

      const job = queue.nextJob(sessionId);
      if (!job) { await sleep(400); continue; }

      // windows and start time
      const startAt = job.start_time ? new Date(job.start_time) : null;
      if (startAt && startAt > new Date()) {
        const wait = startAt.getTime() - Date.now();
        await sleep(wait);
      }
      const stMin = parseTimeStringToMinutes(job.window_start);
      const enMin = parseTimeStringToMinutes(job.window_end);
      while (!inWindow(new Date(), stMin, enMin)) {
        await waitUntilWindow(new Date(), stMin);
      }

      let success = false; let errMsg = '';
      for (let attempt = 0; attempt <= (job.retry_max || 0); attempt += 1) {
        try {
          await sendFromJob(job);
          success = true; break;
        } catch (err) {
          errMsg = String(err?.message || err);
          if (attempt < (job.retry_max || 0)) {
            const backoff = jitteredDelay((job.retry_base_ms || 1000) * Math.pow(2, attempt), job.retry_jitter || 0);
            await sleep(backoff);
          }
        }
      }
      if (success) {
        queue.markJob(job.id, 'sent', null);
        worker.consecutiveFailures = 0;
        worker.messagesSinceThrottle += 1;
      } else {
        queue.markJob(job.id, 'failed', errMsg);
        io.to(getRoom(sessionId)).emit('campaign_progress', { sessionId, id: job.campaign_id, index: job.id, phone: job.phone, status: 'failed', error: errMsg });
        worker.consecutiveFailures += 1;
        if (worker.consecutiveFailures >= FAILURE_BURST_THRESHOLD) {
          logger.warn({ sessionId }, 'Too many failures; cooling down');
          await sleep(FAILURE_COOLDOWN_MS);
          worker.consecutiveFailures = 0;
        }
      }

      // base delay and throttle
      await sleep(Math.max(0, job.delay_ms || 0));
      const every = Math.max(0, job.throttle_every || 0);
      const restSec = Math.max(0, job.throttle_sleep_sec || 0);
      if (every > 0 && restSec > 0 && worker.messagesSinceThrottle % every === 0) {
        await sleep(restSec * 1000);
      }
    } catch (err) {
      logger.error({ sessionId, err: String(err) }, 'Worker error');
      await sleep(1000);
    }
  }
}

// Routes
app.get('/api/sessions', (_req, res) => {
  const data = Array.from(sessions.entries()).map(([id, s]) => ({ 
    id, 
    ready: s.isReady, 
    runningCampaign: Boolean(s.currentCampaign),
    clientConnected: s.client && s.client.info !== null,
    lastSeen: s.lastSeen || null
  }));
  res.json({ sessions: data });
});

app.post('/api/sessions', (req, res) => {
  const { id } = req.body || {};
  if (!id) return res.status(400).json({ error: 'id required' });
  const exists = sessions.get(id);
  const state = exists || ensureSession(id);
  if (!exists) state.client.initialize().catch((e) => {
    try { logger.error({ sessionId: id, error: String(e) }, 'Failed to initialize session'); } catch {}
  });
  res.json({ id, ready: state.isReady });
});

// Reconnect session endpoint (must be before /status route to avoid conflicts)
app.post('/api/sessions/:id/reconnect', async (req, res) => {
  const sessionId = req.params.id;
  const state = sessions.get(sessionId);
  
  if (!state) {
    return res.status(404).json({ error: 'Session not found' });
  }
  
  try {
    logger.info({ sessionId }, 'Manual reconnect requested');
    // Prevent concurrent reconnects
    if (state._reconnecting) {
      return res.json({ success: true, message: 'Reconnect already in progress' });
    }
    state._reconnecting = true;

    try {
      // Attempt graceful destroy first
      try { await state.client.destroy(); } catch {}
      try { await sleep(300); } catch {}

      // Remove potential chromium singleton lock for this session
      try {
        const lockPath = path.join(__dirname, '.wwebjs_auth', `session-whats-tool-${sessionId}`, 'SingletonLock');
        await fs.promises.unlink(lockPath).catch(() => {});
      } catch {}

      // Recreate client instance fresh
      const newState = createClient(sessionId);
      try { await newState.client.initialize(); } catch (e) {
        // If initialize fails, keep old state reference to avoid dangling
        logger.error({ sessionId, error: String(e) }, 'Initialize failed during reconnect');
        throw e;
      }
      res.json({ success: true, message: 'Reconnection initiated. Waiting for readiness.' });
    } finally {
      state._reconnecting = false;
    }
  } catch (error) {
    logger.error({ sessionId, error: String(error) }, 'Failed to reconnect session');
    res.status(500).json({ 
      error: 'Failed to reconnect session', 
      details: String(error) 
    });
  }
});

app.get('/api/sessions/:id/status', (req, res) => {
  const id = req.params.id;
  const state = sessions.get(id);
  if (!state) return res.json({ ready: false, runningCampaign: false, number: null });
  const number = state.isReady ? safeGetClientNumber(state.client) : null;
  const pushName = state?.client?.info?.pushname || null;
  res.json({ ready: state.isReady, runningCampaign: Boolean(state.currentCampaign), number, pushName });
});

// Session health check endpoint
app.get('/api/sessions/:id/health', (req, res) => {
  const sessionId = req.params.id;
  const state = sessions.get(sessionId);
  
  if (!state) {
    return res.status(404).json({ error: 'Session not found' });
  }
  
  const health = {
    sessionId,
    isReady: state.isReady,
    clientConnected: state.client && state.client.info !== null,
    hasClient: !!state.client,
    currentCampaign: state.currentCampaign,
    lastSeen: state.lastSeen || null,
    status: state.isReady && state.client && state.client.info !== null ? 'healthy' : 'unhealthy'
  };
  
  res.json(health);
});

// Session watchdog: periodically ensure clients are initialized
setInterval(() => {
  for (const [sid, st] of sessions.entries()) {
    try {
      if (!st.client || st.client.info === null) {
        // If client missing or not connected, try to initialize with backoff
        const backoff = Math.min(60000, 2000 * Math.pow(2, st.autoReconnectFailures || 0));
        st.autoReconnectFailures = (st.autoReconnectFailures || 0) + 1;
        setTimeout(async () => {
          try {
            // Clean lock and re-init
            try {
              const lockPath = path.join(__dirname, '.wwebjs_auth', `session-whats-tool-${sid}`, 'SingletonLock');
              await fs.promises.unlink(lockPath).catch(() => {});
            } catch {}
            await st.client?.initialize();
          } catch (e) {
            logger.error({ sessionId: sid, error: String(e) }, 'Watchdog initialize failed');
          }
        }, backoff);
      } else {
        st.autoReconnectFailures = 0;
      }
    } catch {}
  }
}, 15000);

// Delete session: logout client (if loaded) and remove LocalAuth data
function deleteDirectoryIfExists(dirPath) {
  try {
    if (fs.existsSync(dirPath)) {
      fs.rmSync(dirPath, { recursive: true, force: true });
    }
  } catch (e) {
    logger.warn({ dirPath, e: String(e) }, 'Failed to remove directory');
  }
}

app.delete('/api/sessions/:id', async (req, res) => {
  const id = req.params.id;
  const state = sessions.get(id);
  if (state) {
    try { if (state.currentCampaign) state.currentCampaign = null; } catch {}
    try { await state.client.logout(); } catch {}
    try { await state.client.destroy(); } catch {}
    sessions.delete(id);
  }
  // Remove auth/cache folders (support both naming conventions)
  const clientId = `whats-tool-${id}`;
  const authBase = path.resolve('.wwebjs_auth');
  const cacheBase = path.resolve('.wwebjs_cache');
  const candidates = [
    path.join(authBase, `session-${clientId}`),
    path.join(authBase, clientId),
    path.join(cacheBase, `session-${clientId}`),
    path.join(cacheBase, clientId),
  ];
  candidates.forEach(deleteDirectoryIfExists);
  res.json({ ok: true });
});

// Delete all sessions endpoint
app.delete('/api/sessions', async (req, res) => {
  try {
    const sessionIds = Array.from(sessions.keys());
    let deletedCount = 0;
    let errors = [];
    
    for (const id of sessionIds) {
      try {
        const state = sessions.get(id);
        if (state) {
          try { if (state.currentCampaign) state.currentCampaign = null; } catch {}
          try { await state.client.logout(); } catch {}
          try { await state.client.destroy(); } catch {}
          sessions.delete(id);
        }
        
        // Remove auth/cache folders (support both naming conventions)
        const clientId = `whats-tool-${id}`;
        const authBase = path.resolve('.wwebjs_auth');
        const cacheBase = path.resolve('.wwebjs_cache');
        const candidates = [
          path.join(authBase, `session-${clientId}`),
          path.join(authBase, clientId),
          path.join(cacheBase, `session-${clientId}`),
          path.join(cacheBase, clientId),
        ];
        candidates.forEach(deleteDirectoryIfExists);
        deletedCount++;
        
        logger.info({ sessionId: id }, 'Session deleted successfully');
      } catch (err) {
        errors.push(`Failed to delete session ${id}: ${String(err)}`);
        logger.error({ sessionId: id, error: String(err) }, 'Failed to delete session');
      }
    }
    
    res.json({ 
      ok: true, 
      deletedCount, 
      totalSessions: sessionIds.length,
      errors: errors.length > 0 ? errors : undefined
    });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// Admin endpoints
app.get('/api/admin/stats', (req, res) => {
  try {
    const stats = {
      sessions: {
        total: sessions.size,
        ready: Array.from(sessions.values()).filter(s => s.isReady).length,
        runningCampaigns: Array.from(sessions.values()).filter(s => s.currentCampaign).length
      },
      flows: {
        total: savedFlows.size,
        active: Array.from(savedFlows.values()).filter(f => f.nodes && f.nodes.length > 0).length
      },
      userTags: {
        total: userTags.size,
        totalTags: Array.from(userTags.values()).reduce((sum, tags) => sum + tags.size, 0)
      },
      system: {
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        version: process.version,
        platform: process.platform
      }
    };
    
    res.json(stats);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// Clear all flows endpoint
app.delete('/api/admin/flows', (req, res) => {
  try {
    const flowIds = Array.from(savedFlows.keys());
    savedFlows.clear();
    saveFlowsToFile();
    
    logger.info({ deletedCount: flowIds.length }, 'All flows cleared');
    res.json({ 
      ok: true, 
      deletedCount: flowIds.length,
      message: `Cleared ${flowIds.length} flows`
    });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// Clear all user tags endpoint
app.delete('/api/admin/user-tags', (req, res) => {
  try {
    const userCount = userTags.size;
    userTags.clear();
    saveUserTagsToFile();
    
    logger.info({ deletedCount: userCount }, 'All user tags cleared');
    res.json({ 
      ok: true, 
      deletedCount: userCount,
      message: `Cleared tags for ${userCount} users`
    });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// Clear all queue data endpoint (campaigns and jobs)
app.delete('/api/admin/queue', (req, res) => {
  try {
    // Get counts before deletion
    const jobCount = queue.db.prepare('SELECT COUNT(*) as count FROM jobs').get().count;
    const campaignCount = queue.db.prepare('SELECT COUNT(*) as count FROM campaigns').get().count;
    
    // Clear all data from queue database
    queue.db.exec('DELETE FROM jobs');
    queue.db.exec('DELETE FROM campaigns');
    
    logger.info({ deletedJobs: jobCount, deletedCampaigns: campaignCount }, 'All queue data cleared');
    res.json({ 
      ok: true, 
      deletedCount: jobCount + campaignCount,
      deletedJobs: jobCount,
      deletedCampaigns: campaignCount,
      message: `Cleared ${jobCount} jobs and ${campaignCount} campaigns`
    });
  } catch (e) {
    logger.error({ error: String(e) }, 'Failed to clear queue data');
    res.status(500).json({ error: String(e) });
  }
});

// Get contacts for a session
app.get('/api/contacts/:sessionId', async (req, res) => {
  const sessionId = req.params.sessionId;
  try {
    const state = sessions.get(sessionId);
    
    if (!state || !state.isReady) {
      return res.status(400).json({ error: 'Session not ready' });
    }
    
    const contacts = await state.client.getContacts();
    
    // Filter and format contacts
    const formattedContacts = contacts
      .filter(contact => contact.id && contact.id._serialized)
      .map(contact => ({
        id: contact.id,
        name: contact.name,
        pushname: contact.pushname,
        formattedName: contact.formattedName,
        number: contact.number,
        isGroup: contact.isGroup || false,
        isUser: contact.isUser || false,
        isWAContact: contact.isWAContact || false
      }));
    
    res.json(formattedContacts);
  } catch (e) {
    logger.error({ sessionId, error: String(e) }, 'Failed to get contacts');
    res.status(500).json({ error: String(e) });
  }
});

// Get chats for a session with pagination
app.get('/api/chats/:sessionId', async (req, res) => {
  const sessionId = req.params.sessionId;
  try {
    const { limit = 100, offset = 0, timeout = 30000 } = req.query;
    
    const state = sessions.get(sessionId);
    
    if (!state || !state.isReady) {
      return res.status(400).json({ error: 'Session not ready' });
    }
    
    // Set up timeout for the entire operation
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Request timeout - too many chats to load')), parseInt(timeout));
    });
    
    const loadChatsPromise = (async () => {
      const chats = await state.client.getChats();
      const totalChats = chats.length;
      
      // Apply pagination
      const startIndex = parseInt(offset);
      const endIndex = startIndex + parseInt(limit);
      const paginatedChats = chats.slice(startIndex, endIndex);
      
      // Process chats in smaller batches to avoid memory issues
      const batchSize = 10;
      const formattedChats = [];
      
      for (let i = 0; i < paginatedChats.length; i += batchSize) {
        const batch = paginatedChats.slice(i, i + batchSize);
        
        const batchResults = await Promise.all(batch.map(async (chat) => {
          try {
            const contact = await chat.getContact();
            // Try to fetch the most recent message for preview/time like phone app
            let lastText = '';
            let lastTimestamp = chat.timestamp;
            try {
              const msgs = await chat.fetchMessages({ limit: 1 });
              const last = Array.isArray(msgs) && msgs.length ? msgs[0] : null;
              if (last) {
                lastText = typeof last.body === 'string' && last.body.trim().length
                  ? last.body.trim()
                  : (last.hasMedia ? '[Media]' : '');
                lastTimestamp = last.timestamp || lastTimestamp;
              }
            } catch {}
            return {
              id: chat.id,
              name: chat.name,
              isGroup: chat.isGroup,
              isReadOnly: chat.isReadOnly,
              unreadCount: chat.unreadCount,
              timestamp: chat.timestamp,
              lastText,
              lastTimestamp,
              contact: contact ? {
                id: contact.id,
                name: contact.name,
                pushname: contact.pushname,
                formattedName: contact.formattedName,
                number: contact.number,
                isGroup: contact.isGroup || false
              } : null
            };
          } catch (error) {
            logger.warn({ sessionId, chatId: chat.id?._serialized, error: String(error) }, 'Failed to get contact for chat');
            return {
              id: chat.id,
              name: chat.name,
              isGroup: chat.isGroup,
              isReadOnly: chat.isReadOnly,
              unreadCount: chat.unreadCount,
              timestamp: chat.timestamp,
              contact: null
            };
          }
        }));
        
        formattedChats.push(...batchResults);
        
        // Small delay between batches to prevent overwhelming the system
        if (i + batchSize < paginatedChats.length) {
          await new Promise(resolve => setTimeout(resolve, 100));
        }
      }
      
      return {
        chats: formattedChats,
        total: totalChats,
        limit: parseInt(limit),
        offset: parseInt(offset),
        hasMore: endIndex < totalChats
      };
    })();
    
    const result = await Promise.race([loadChatsPromise, timeoutPromise]);
    res.json(result);
    
  } catch (e) {
    const msg = String(e || '');
    logger.error({ sessionId, error: msg }, 'Failed to get chats');
    // If chromium page/session is closed, trigger reconnect and inform client
    if (msg.includes('Session closed') || msg.includes('browser has disconnected') || msg.includes('Target closed')) {
      try { await triggerReconnect(sessionId); } catch {}
      return res.status(503).json({ error: 'whatsapp_session_closed', message: 'Session closed. Reconnecting…', reconnecting: true });
    }
    
    // Provide more specific error messages
    if (msg.includes('timeout')) {
      res.status(408).json({ 
        error: 'Request timeout - your contact list is too large. Try using pagination with smaller limits.',
        suggestion: 'Use ?limit=50&offset=0 to load contacts in smaller batches'
      });
    } else if (msg.includes('memory') || msg.includes('heap')) {
      res.status(507).json({ 
        error: 'Insufficient memory to load all chats. Please use pagination.',
        suggestion: 'Use ?limit=25&offset=0 to reduce memory usage'
      });
    } else {
      res.status(500).json({ error: msg });
    }
  }
});

// Send message to contact
app.post('/api/send-message', async (req, res) => {
  const { sessionId, phone, message, mediaPath, caption } = req.body;
  try {
    
    if (!sessionId || !phone) {
      return res.status(400).json({ error: 'sessionId and phone are required' });
    }
    
    const state = sessions.get(sessionId);
    if (!state || !state.isReady) {
      return res.status(400).json({ error: 'Session not ready' });
    }
    
    // Create item object for sendItem function
    const item = { phone: phone };
    if (mediaPath) { item.mediaPath = mediaPath; if (caption) item.caption = caption; if (message && !caption) item.message = message; }
    else { item.message = message || ''; }
    
    // Send the message
    await sendItem(state, item);
    
    logger.info({ sessionId, phone, messageLength: (message ? message.length : 0) }, 'Message sent successfully');
    // Activate human takeover automatically when owner replies manually
    try {
      const chatId = phone.includes('@c.us') ? phone : `${String(phone).replace(/[^0-9]/g,'')}@c.us`;
      setHumanOverride(sessionId, chatId, 15, 'all');
      logger.info({ sessionId, chatId }, 'Activated human takeover for 15 minutes after manual send');
    } catch {}
    res.json({ 
      success: true, 
      message: 'Message sent successfully',
      phone: phone,
      sessionId: sessionId
    });
    
  } catch (e) {
    logger.error({ sessionId, phone, error: String(e) }, 'Failed to send message');
    res.status(500).json({ error: String(e) });
  }
});

// Get message history for a contact
app.get('/api/messages/:sessionId/:contactId', async (req, res) => {
  const { sessionId, contactId } = req.params;
  try {
    const { limit = 50 } = req.query;
    
    const state = sessions.get(sessionId);
    if (!state || !state.isReady) {
      return res.status(400).json({ error: 'Session not ready' });
    }
    
    try {
      // Get chat by contact ID
      const chat = await state.client.getChatById(contactId);
      if (!chat) {
        return res.status(404).json({ error: 'Chat not found' });
      }
      
      // Try to fetch messages from the chat
      let messages = [];
      try {
        messages = await chat.fetchMessages({ limit: parseInt(limit) });
      } catch (fetchError) {
        logger.warn({ sessionId, contactId, error: String(fetchError) }, 'Failed to fetch messages, returning empty array');
        // Return empty messages array instead of failing
        return res.json({
          contactId: contactId,
          chatName: chat.name || 'Unknown',
          isGroup: chat.isGroup || false,
          messages: [],
          total: 0,
          warning: 'Unable to load message history. Chat may not exist or be corrupted.'
        });
      }
      
      // Format messages
      const formattedMessages = messages.map(msg => ({
        id: msg.id._serialized,
        body: msg.body,
        from: msg.from,
        to: msg.to,
        fromMe: msg.fromMe,
        timestamp: msg.timestamp,
        type: msg.type,
        hasMedia: msg.hasMedia,
        mediaType: msg.hasMedia ? msg.type : null,
        quotedMsg: msg.quotedMsg ? {
          id: msg.quotedMsg.id._serialized,
          body: msg.quotedMsg.body,
          fromMe: msg.quotedMsg.fromMe
        } : null,
        ack: msg.ack,
        isStatus: msg.isStatus,
        isForwarded: msg.isForwarded
      }));
      
      res.json({
        contactId: contactId,
        chatName: chat.name,
        isGroup: chat.isGroup,
        messages: formattedMessages,
        total: formattedMessages.length
      });
      
    } catch (chatError) {
      // Handle specific WhatsApp Web errors
      if (String(chatError).includes('Lid is missing') || 
          String(chatError).includes('chat table') ||
          String(chatError).includes('Evaluation failed')) {
        
        logger.warn({ sessionId, contactId, error: String(chatError) }, 'WhatsApp Web chat error - chat may not exist');
        
        return res.json({
          contactId: contactId,
          chatName: 'Unknown',
          isGroup: false,
          messages: [],
          total: 0,
          warning: 'Chat not found or corrupted. This contact may not have an active chat history.',
          error: 'Chat table error - contact may need to be contacted first'
        });
      }
      
      throw chatError;
    }
    
  } catch (e) {
    logger.error({ sessionId, contactId, error: String(e) }, 'Failed to get messages');
    res.status(500).json({ error: String(e) });
  }
});

// Get sent messages from queue database
app.get('/api/sent-messages/:sessionId', async (req, res) => {
  const sessionId = req.params.sessionId;
  try {
    const { limit = 100, offset = 0 } = req.query;
    
    // Get sent messages from queue database
    const sentMessages = queue.db.prepare(`
      SELECT 
        j.id,
        j.campaign_id,
        j.phone,
        j.message,
        j.caption,
        j.media_path,
        j.status,
        j.created_at,
        j.updated_at,
        c.meta as campaign_meta
      FROM jobs j
      LEFT JOIN campaigns c ON j.campaign_id = c.id
      WHERE j.session_id = ? AND j.status = 'sent'
      ORDER BY j.updated_at DESC
      LIMIT ? OFFSET ?
    `).all(sessionId, parseInt(limit), parseInt(offset));
    
    // Get total count
    const totalCount = queue.db.prepare(`
      SELECT COUNT(*) as count
      FROM jobs
      WHERE session_id = ? AND status = 'sent'
    `).get(sessionId).count;
    
    res.json({
      messages: sentMessages,
      total: totalCount,
      limit: parseInt(limit),
      offset: parseInt(offset)
    });
    
  } catch (e) {
    logger.error({ sessionId, error: String(e) }, 'Failed to get sent messages');
    res.status(500).json({ error: String(e) });
  }
});

// System health endpoint
app.get('/api/admin/health', (req, res) => {
  try {
    const health = {
      status: 'healthy',
      timestamp: new Date().toISOString(),
      services: {
        database: 'healthy',
        sessions: sessions.size >= 0 ? 'healthy' : 'warning',
        flows: savedFlows.size >= 0 ? 'healthy' : 'warning',
        cron: 'healthy'
      },
      memory: {
        used: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
        total: Math.round(process.memoryUsage().heapTotal / 1024 / 1024),
        external: Math.round(process.memoryUsage().external / 1024 / 1024)
      },
      uptime: Math.round(process.uptime())
    };
    
    res.json(health);
  } catch (e) {
    res.status(500).json({ 
      status: 'error',
      error: String(e),
      timestamp: new Date().toISOString()
    });
  }
});

app.post('/api/upload', upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file' });
  return res.json({ filename: req.file.filename, url: `/uploads/${req.file.filename}` });
});

// Queue controls and stats
app.post('/api/queue/pause', (req, res) => {
  const { sessionId } = req.body || {};
  if (sessionId) {
    const w = workers.get(sessionId);
    if (w) w.paused = true;
  } else {
    for (const [, w] of workers.entries()) w.paused = true;
  }
  res.json({ ok: true });
});

app.post('/api/queue/resume', (req, res) => {
  const { sessionId } = req.body || {};
  if (sessionId) {
    const w = workers.get(sessionId);
    if (w) w.paused = false;
  } else {
    for (const [, w] of workers.entries()) w.paused = false;
  }
  res.json({ ok: true });
});

app.get('/api/queue/stats', (_req, res) => {
  const list = Array.from(sessions.entries()).map(([id, st]) => ({
    id,
    ready: st.isReady,
    pending: queue.pendingCount(id),
    stats: queue.sessionStats(id),
    worker: {
      running: Boolean(workers.get(id)?.running),
      paused: Boolean(workers.get(id)?.paused),
    },
  }));
  res.json({ sessions: list });
});

app.get('/api/campaign/:id/export', (req, res) => {
  const csv = queue.exportCsv(req.params.id);
  res.set('Content-Type', 'text/csv');
  res.set('Content-Disposition', `attachment; filename="${req.params.id}.csv"`);
  res.send(csv);
});

app.get('/api/campaigns', (req, res) => {
  const limit = Math.max(1, Math.min(100, Number(req.query.limit) || 10));
  const page = Math.max(0, Number(req.query.page) || 0);
  const offset = page * limit;
  res.json({ campaigns: queue.listCampaigns(limit, offset), page, limit });
});

// Simple in-memory flow storage with file persistence
const savedFlows = new Map();
const flowsFile = path.join(process.cwd(), 'data', 'flows.json');
const flowAnalytics = new Map(); // Track flow execution stats
const cronJobs = new Map(); // Track cron jobs for flows
const userTags = new Map(); // Track user tags: phone -> Set of tags
const userTagsFile = path.join(process.cwd(), 'data', 'user_tags.json');

// Load flows from file on startup
try {
  // Ensure data directory exists
  const dataDir = path.dirname(flowsFile);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  if (fs.existsSync(flowsFile)) {
    const data = fs.readFileSync(flowsFile, 'utf8');
    const flows = JSON.parse(data);
    flows.forEach(flow => savedFlows.set(flow.id, flow));
    logger.info({ count: flows.length }, 'Loaded saved flows from file');
  }
} catch (e) {
  logger.error({ error: String(e) }, 'Failed to load flows from file');
}

// Save flows to file
function saveFlowsToFile() {
  try {
    const flows = Array.from(savedFlows.values());
    fs.writeFileSync(flowsFile, JSON.stringify(flows, null, 2));
    logger.info({ count: flows.length }, 'Saved flows to file');
  } catch (e) {
    logger.error({ error: String(e) }, 'Failed to save flows to file');
  }
}

// Load user tags from file
function loadUserTagsFromFile() {
  try {
    if (fs.existsSync(userTagsFile)) {
      const data = JSON.parse(fs.readFileSync(userTagsFile, 'utf8'));
      for (const [phone, tags] of Object.entries(data)) {
        userTags.set(phone, new Set(tags));
      }
      logger.info({ count: userTags.size }, 'Loaded user tags from file');
    }
  } catch (e) {
    logger.error({ error: String(e) }, 'Failed to load user tags from file');
  }
}

// Save user tags to file
function saveUserTagsToFile() {
  try {
    const data = {};
    for (const [phone, tags] of userTags.entries()) {
      data[phone] = Array.from(tags);
    }
    fs.writeFileSync(userTagsFile, JSON.stringify(data, null, 2));
    logger.info({ count: userTags.size }, 'Saved user tags to file');
  } catch (e) {
    logger.error({ error: String(e) }, 'Failed to save user tags to file');
  }
}

// Flow Builder API
app.get('/api/flows', (req, res) => {
  try {
    const sessionId = req.query.sessionId;
    const flows = Array.from(savedFlows.values()).filter(f => !sessionId || f.sessionId === sessionId);
    logger.info({ count: flows.length, sessionId }, 'Retrieved flows');
    res.json({ flows });
  } catch (e) {
    logger.error({ error: String(e) }, 'Failed to retrieve flows');
    res.status(500).json({ error: String(e) });
  }
});

// Test endpoint to check if flows API is working
app.get('/api/flows/test', (req, res) => {
  res.json({ 
    status: 'ok', 
    message: 'Flows API is working',
    flowsCount: savedFlows.size,
    timestamp: new Date().toISOString()
  });
});

// User tags API
app.get('/api/user-tags', (req, res) => {
  try {
    const phone = req.query.phone;
    if (phone) {
      const tags = userTags.get(phone) ? Array.from(userTags.get(phone)) : [];
      res.json({ phone, tags });
    } else {
      const allTags = {};
      for (const [phone, tags] of userTags.entries()) {
        allTags[phone] = Array.from(tags);
      }
      res.json({ userTags: allTags });
    }
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

app.post('/api/user-tags', (req, res) => {
  try {
    const { phone, tag, action } = req.body || {};
    if (!phone || !tag) return res.status(400).json({ error: 'phone and tag required' });
    
    if (!userTags.has(phone)) {
      userTags.set(phone, new Set());
    }
    
    const userTagSet = userTags.get(phone);
    
    switch (action) {
      case 'add':
        userTagSet.add(tag);
        break;
      case 'remove':
        userTagSet.delete(tag);
        break;
      case 'replace':
        userTags.set(phone, new Set([tag]));
        break;
      default:
        return res.status(400).json({ error: 'action must be add, remove, or replace' });
    }
    
    saveUserTagsToFile();
    res.json({ phone, tags: Array.from(userTagSet) });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// Debug endpoint for testing conditions
app.post('/api/flows/debug', (req, res) => {
  try {
    const { sessionId, phone, message, trigger } = req.body || {};
    
    // Create test context
    const userData = {
      phone: phone || '201001234567',
      messageCount: 0,
      lastMessage: message || 'test message'
    };
    
    const messageData = {
      messageText: message || 'test message',
      senderName: 'Test User',
      senderPhone: phone || '201001234567',
      chatTitle: 'Test Chat'
    };
    
    const context = { userData, messageData, sessionId: sessionId || '00' };
    
    // Test trigger evaluation if provided
    if (trigger) {
      const wouldTrigger = evaluateTrigger(trigger, message || 'test message', 'test_chat', sessionId || '00');
      res.json({ 
        wouldTrigger,
        trigger,
        context: {
          userData,
          messageData,
          userTags: userTags.has(userData.phone) ? Array.from(userTags.get(userData.phone)) : []
        }
      });
      return;
    }
    
    // Test condition evaluation
    const { conditionType, condition } = req.body;
    if (conditionType && condition) {
      const fullCondition = `${conditionType}:${condition}`;
      const result = evaluateCondition(fullCondition, context);
      res.json({ 
        conditionType,
        condition,
        result,
        context: {
          userData,
          messageData,
          userTags: userTags.has(userData.phone) ? Array.from(userTags.get(userData.phone)) : []
        }
      });
      return;
    }
    
    res.json({ 
      message: 'Debug endpoint - provide trigger or conditionType+condition',
      context: {
        userData,
        messageData,
        userTags: userTags.has(userData.phone) ? Array.from(userTags.get(userData.phone)) : []
      }
    });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// Cron schedule information endpoint
app.get('/api/cron/schedule', (req, res) => {
  try {
    const cronFlows = [];
    
    for (const [flowId, flow] of savedFlows.entries()) {
      const triggerNode = flow.nodes.find(node => node.type === 'trigger');
      if (triggerNode && triggerNode.data.triggerType === 'cron') {
        cronFlows.push({
          flowId,
          flowName: flow.name,
          sessionId: flow.sessionId,
          cronExpression: triggerNode.data.condition,
          cronType: triggerNode.data.cronType || 'advanced',
          description: triggerNode.data.description || '',
          nextExecution: calculateNextCronExecution(triggerNode.data.condition)
        });
      }
    }
    
    res.json({
      cronFlows,
      totalCronFlows: cronFlows.length,
      schedulerStatus: 'running',
      lastCheck: new Date().toISOString()
    });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// Helper function to calculate next cron execution
function calculateNextCronExecution(cronExpression) {
  if (!cronExpression) return null;
  
  try {
    const now = new Date();
    const parts = cronExpression.trim().split(/\s+/);
    if (parts.length !== 5) return null;
    
    const [minute, hour, day, month, weekday] = parts;
    
    // Find next execution time
    let nextRun = new Date(now);
    nextRun.setSeconds(0, 0);
    
    // Simple calculation for common patterns
    if (minute !== '*' && hour !== '*') {
      nextRun.setMinutes(parseInt(minute));
      nextRun.setHours(parseInt(hour));
      
      // If time has passed today, move to next day
      if (nextRun <= now) {
        nextRun.setDate(nextRun.getDate() + 1);
      }
      
      // Handle weekday restrictions
      if (weekday !== '*') {
        const targetDays = weekday.split(',').map(d => parseInt(d));
        while (!targetDays.includes(nextRun.getDay())) {
          nextRun.setDate(nextRun.getDate() + 1);
        }
      }
      
      // Handle day of month restrictions
      if (day !== '*') {
        const targetDay = parseInt(day);
        if (nextRun.getDate() !== targetDay) {
          nextRun.setDate(targetDay);
          if (nextRun <= now) {
            nextRun.setMonth(nextRun.getMonth() + 1);
            nextRun.setDate(targetDay);
          }
        }
      }
    }
    
    return nextRun.toISOString();
  } catch (e) {
    return null;
  }
}

app.post('/api/flows', (req, res) => {
  try {
    const { name, sessionId, tags, nodes, edges } = req.body || {};
    logger.info({ name, sessionId, tags, nodeCount: nodes?.length, edgeCount: edges?.length }, 'Creating new flow');
    
    if (!name) return res.status(400).json({ error: 'name required' });
    
    const flow = {
      id: Date.now().toString(),
      name,
      sessionId,
      tags: tags || [],
      nodes,
      edges,
      createdAt: new Date().toISOString()
    };
    
    savedFlows.set(flow.id, flow);
    saveFlowsToFile(); // Persist to file
    logger.info({ flowId: flow.id, name, tags }, 'Flow created successfully');
    res.json(flow);
  } catch (e) {
    logger.error({ error: String(e) }, 'Failed to create flow');
    res.status(500).json({ error: String(e) });
  }
});

app.put('/api/flows/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { name, sessionId, tags, nodes, edges } = req.body || {};
    logger.info({ id, name, sessionId, tags, nodeCount: nodes?.length, edgeCount: edges?.length }, 'Updating flow');
    
    if (!savedFlows.has(id)) {
      logger.warn({ id }, 'Flow not found for update');
      return res.status(404).json({ error: 'Flow not found' });
    }
    
    if (!name) return res.status(400).json({ error: 'name required' });
    
    const existingFlow = savedFlows.get(id);
    const updatedFlow = {
      ...existingFlow,
      name,
      sessionId,
      tags: tags || [],
      nodes,
      edges,
      updatedAt: new Date().toISOString()
    };
    
    savedFlows.set(id, updatedFlow);
    saveFlowsToFile(); // Persist to file
    logger.info({ id, name, tags }, 'Flow updated successfully');
    res.json(updatedFlow);
  } catch (e) {
    logger.error({ id, error: String(e) }, 'Failed to update flow');
    res.status(500).json({ error: String(e) });
  }
});

app.delete('/api/flows/:id', (req, res) => {
  try {
    const { id } = req.params;
    if (savedFlows.has(id)) {
      savedFlows.delete(id);
      saveFlowsToFile(); // Persist to file
      res.json({ success: true });
    } else {
      res.status(404).json({ error: 'Flow not found' });
    }
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// Debug endpoint to test flow triggers
app.post('/api/flows/debug', (req, res) => {
  try {
    const { sessionId, message, phone } = req.body || {};
    if (!sessionId || !message) return res.status(400).json({ error: 'sessionId and message required' });
    
    const flows = Array.from(savedFlows.values()).filter(f => f.sessionId === sessionId);
    const results = [];
    
    for (const flow of flows) {
      const triggerNode = flow.nodes.find(n => n.type === 'trigger');
      if (!triggerNode) {
        results.push({ flowId: flow.id, flowName: flow.name, error: 'No trigger node' });
        continue;
      }
      
      const shouldTrigger = evaluateTrigger(triggerNode, message, phone || 'test', sessionId);
      const analytics = flowAnalytics.get(flow.id) || { executions: 0, successes: 0, failures: 0, lastExecuted: null };
      
      results.push({
        flowId: flow.id,
        flowName: flow.name,
        triggerType: triggerNode.data?.triggerType,
        condition: triggerNode.data?.condition,
        shouldTrigger,
        nodes: flow.nodes.length,
        analytics
      });
    }
    
    res.json({ 
      sessionId, 
      testMessage: message, 
      flowsFound: flows.length, 
      results 
    });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// Flow analytics endpoint
app.get('/api/flows/analytics', (req, res) => {
  try {
    const sessionId = req.query.sessionId;
    const flows = Array.from(savedFlows.values()).filter(f => !sessionId || f.sessionId === sessionId);
    
    const analytics = flows.map(flow => ({
      flowId: flow.id,
      flowName: flow.name,
      sessionId: flow.sessionId,
      nodes: flow.nodes.length,
      edges: flow.edges.length,
      createdAt: flow.createdAt,
      stats: flowAnalytics.get(flow.id) || { executions: 0, successes: 0, failures: 0, lastExecuted: null }
    }));
    
    res.json({ analytics });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// Enhanced condition evaluation with branching logic
function evaluateCondition(condition, context) {
  const { userData, systemVars, messageData } = context;
  
  try {
    // Parse condition type and parameters
    const parts = condition.split(':');
    const type = parts[0];
    const params = parts.slice(1);
    
    switch (type) {
      case 'equals':
        return userData[params[0]] === params[1];
      case 'contains':
        return (userData[params[0]] || '').toLowerCase().includes(params[1].toLowerCase());
      case 'greater_than':
        return Number(userData[params[0]] || 0) > Number(params[1]);
      case 'less_than':
        return Number(userData[params[0]] || 0) < Number(params[1]);
      case 'time_between':
        const now = new Date();
        const start = new Date(`${now.toDateString()} ${params[0]}`);
        const end = new Date(`${now.toDateString()} ${params[1]}`);
        return now >= start && now <= end;
      case 'day_of_week':
        const day = now.getDay();
        const targetDays = params[0].split(',').map(d => Number(d));
        return targetDays.includes(day);
      case 'message_count':
        return (userData.messageCount || 0) >= Number(params[0]);
      case 'has_media':
        return messageData.hasMedia || false;
      case 'is_group':
        return messageData.isGroup || false;
      case 'has_tag':
        // Check if user has specific tag
        const phone = userData.phone;
        const tagToCheck = params[0];
        logger.info({ 
          phone, 
          tagToCheck, 
          hasUserTags: userTags.has(phone),
          userTags: userTags.has(phone) ? Array.from(userTags.get(phone)) : []
        }, 'Checking has_tag condition');
        if (phone && userTags.has(phone)) {
          const result = userTags.get(phone).has(tagToCheck);
          logger.info({ phone, tagToCheck, result }, 'has_tag result');
          return result;
        }
        return false;
      case 'has_any_tag':
        // Check if user has any of the specified tags
        const phoneAny = userData.phone;
        const tagsToCheck = params[0].split(',').map(t => t.trim());
        if (phoneAny && userTags.has(phoneAny)) {
          const userTagSet = userTags.get(phoneAny);
          return tagsToCheck.some(tag => userTagSet.has(tag));
        }
        return false;
      case 'has_all_tags':
        // Check if user has all of the specified tags
        const phoneAll = userData.phone;
        const allTagsToCheck = params[0].split(',').map(t => t.trim());
        if (phoneAll && userTags.has(phoneAll)) {
          const userTagSet = userTags.get(phoneAll);
          return allTagsToCheck.every(tag => userTagSet.has(tag));
        }
        return false;
      default:
        return false;
    }
  } catch (e) {
    logger.error({ error: String(e), condition }, 'Error evaluating condition');
    return false;
  }
}

// Dynamic variables system
function replaceDynamicVars(text, context) {
  const { userData, systemVars, messageData } = context;
  
  // Use the enhanced replaceSystemVars function for date/time variables
  text = replaceSystemVars(text);
  
  // Additional context-specific variables
  text = text.replace(/\{session_id\}/g, context.sessionId || '');
  text = text.replace(/\{random_number\}/g, Math.floor(Math.random() * 1000));
  
  // User data variables
  Object.keys(userData).forEach(key => {
    const regex = new RegExp(`\\{${key}\\}`, 'g');
    text = text.replace(regex, userData[key] || '');
  });
  
  // Message data variables
  text = text.replace(/\{sender_name\}/g, messageData.senderName || '');
  text = text.replace(/\{sender_phone\}/g, messageData.senderPhone || '');
  text = text.replace(/\{message_text\}/g, messageData.messageText || '');
  text = text.replace(/\{chat_title\}/g, messageData.chatTitle || '');
  
  // User tag variables
  const phone = userData?.phone;
  if (phone && userTags.has(phone)) {
    const tags = Array.from(userTags.get(phone));
    text = text.replace(/\{user_tags\}/g, tags.join(', '));
    text = text.replace(/\{user_tags_count\}/g, tags.length.toString());
    
    // Individual tag access: {user_tags_0}, {user_tags_1}, etc.
    tags.forEach((tag, index) => {
      text = text.replace(new RegExp(`\\{user_tags_${index}\\}`, 'g'), tag);
    });
    
    // Check if user has specific tag: {has_tag_vip}, {has_tag_premium}, etc.
    tags.forEach(tag => {
      text = text.replace(new RegExp(`\\{has_tag_${tag}\\}`, 'g'), 'true');
    });
  } else {
    text = text.replace(/\{user_tags\}/g, '');
    text = text.replace(/\{user_tags_count\}/g, '0');
  }
  
  // Handle has_tag_ variables for tags user doesn't have
  text = text.replace(/\{has_tag_([^}]+)\}/g, 'false');
  
  return text;
}

// Enhanced trigger evaluation with advanced types
function evaluateTrigger(trigger, message, chatId, sessionId) {
  const { triggerType, condition } = trigger.data || {};
  
  logger.info({ 
    triggerType, 
    condition, 
    message, 
    messageLength: message?.length,
    hasCondition: !!condition,
    hasMessage: !!message
  }, 'Evaluating trigger');
  
  try {
    switch (triggerType) {
      case 'keyword':
        if (!condition || !message) {
          logger.warn({ condition, message }, 'Keyword trigger missing condition or message');
          return false;
        }
        const keywords = condition.toLowerCase().split(',').map(k => k.trim());
        const messageLower = message.toLowerCase();
        const matches = keywords.filter(keyword => messageLower.includes(keyword));
        
        logger.info({ 
          keywords, 
          messageLower, 
          matches, 
          willTrigger: matches.length > 0 
        }, 'Keyword matching details');
        
        return matches.length > 0;
        
      case 'time':
        const now = new Date();
        const [startTime, endTime] = condition.split('-');
        const start = new Date(`${now.toDateString()} ${startTime}`);
        const end = new Date(`${now.toDateString()} ${endTime}`);
        return now >= start && now <= end;
        
      case 'message_count':
        // This would need to be tracked per user
        return true; // Placeholder - would need user message count tracking
        
      case 'time_based':
        const [days, hours] = condition.split('|');
        const targetDays = days.split(',').map(d => Number(d));
        const targetHours = hours.split(',').map(h => Number(h));
        const currentDay = now.getDay();
        const currentHour = now.getHours();
        return targetDays.includes(currentDay) && targetHours.includes(currentHour);
        
      case 'user_behavior':
        // This would need user behavior tracking
        return true; // Placeholder - would need user behavior analysis
        
      case 'webhook':
        // This would trigger external webhook
        return true; // Placeholder - would need webhook integration
        
      case 'cron':
        // Cron triggers are handled separately by the cron scheduler
        // This function is for message-based triggers, so cron always returns false here
        return false;
        
      case 'always':
      default:
        return true;
    }
  } catch (e) {
    logger.error({ error: String(e), trigger }, 'Error evaluating trigger');
    return false;
  }
}

// Smart cron scheduler for flow triggers
function startCronScheduler() {
  logger.info('Starting smart cron scheduler for flow triggers');
  
  // Check every minute for cron triggers
  setInterval(() => {
    const now = new Date();
    let executedFlows = 0;
    
    for (const [flowId, flow] of savedFlows.entries()) {
      const triggerNode = flow.nodes.find(node => node.type === 'trigger');
      if (!triggerNode || triggerNode.data.triggerType !== 'cron') continue;
      
      const cronExpression = triggerNode.data.condition;
      if (!cronExpression) continue;
      
      // Check if cron expression matches current time
      if (isCronTimeMatch(cronExpression, now)) {
        logger.info({ 
          flowId, 
          flowName: flow.name, 
          cronExpression,
          cronType: triggerNode.data.cronType || 'advanced',
          time: now.toISOString()
        }, 'Cron trigger matched, executing flow');
        
        // Execute flow for the specified session
        const sessionId = flow.sessionId;
        const state = sessions.get(sessionId);
        
        if (state && state.isReady) {
          // For cron triggers, execute for all users with tags
          let userExecutions = 0;
          
          // Check if this flow has condition nodes that check for tags
          const hasTagConditions = flow.nodes.some(node => 
            node.type === 'condition' && 
            node.data?.conditionType && 
            ['has_tag', 'has_any_tag', 'has_all_tags'].includes(node.data.conditionType)
          );
          
          if (hasTagConditions) {
            // Execute for all users with tags
            for (const [phone, userTagSet] of userTags.entries()) {
              if (userTagSet && userTagSet.size > 0) {
                logger.info({ 
                  flowId, 
                  flowName: flow.name, 
                  phone, 
                  userTags: Array.from(userTagSet) 
                }, 'Executing cron flow for tagged user');
                
                executeFlow(flow, phone, sessionId, {
                  messageText: `Scheduled message from ${flow.name}`,
                  sender_name: 'System Scheduler',
                  sender_phone: 'system',
                  chat_title: 'Scheduled Flow',
                  isCronTrigger: true,
                  triggerTime: now.toISOString()
                }).catch(err => {
                  logger.error({ 
                    flowId, 
                    flowName: flow.name, 
                    phone, 
                    error: String(err) 
                  }, 'Cron flow execution failed for user');
                });
                
                userExecutions++;
              }
            }
          } else {
            // For flows without tag conditions, execute with system context
            executeFlow(flow, 'cron_trigger', sessionId, {
              messageText: `Scheduled message from ${flow.name}`,
              sender_name: 'System Scheduler',
              sender_phone: 'system',
              chat_title: 'Scheduled Flow',
              isCronTrigger: true,
              triggerTime: now.toISOString()
            });
            userExecutions = 1;
          }
          
          executedFlows += userExecutions;
          logger.info({ 
            flowId, 
            flowName: flow.name, 
            sessionId, 
            userExecutions 
          }, 'Cron flow executed successfully');
        } else {
          logger.warn({ 
            flowId, 
            flowName: flow.name, 
            sessionId, 
            isReady: state?.isReady 
          }, 'Cron flow skipped - session not ready');
        }
      }
    }
    
    if (executedFlows > 0) {
      logger.info({ executedFlows, time: now.toISOString() }, 'Cron scheduler completed execution cycle');
    }
  }, 60000); // Check every minute
}

// Simple cron expression matcher
function isCronTimeMatch(cronExpression, date) {
  try {
    const parts = cronExpression.trim().split(/\s+/);
    if (parts.length !== 5) return false;
    
    const [minute, hour, day, month, weekday] = parts;
    
    // Check minute
    if (minute !== '*' && !isTimeMatch(minute, date.getMinutes())) return false;
    
    // Check hour
    if (hour !== '*' && !isTimeMatch(hour, date.getHours())) return false;
    
    // Check day of month
    if (day !== '*' && !isTimeMatch(day, date.getDate())) return false;
    
    // Check month
    if (month !== '*' && !isTimeMatch(month, date.getMonth() + 1)) return false;
    
    // Check weekday (0 = Sunday, 1 = Monday, etc.)
    if (weekday !== '*' && !isTimeMatch(weekday, date.getDay())) return false;
    
    return true;
  } catch (e) {
    logger.error({ cronExpression, error: String(e) }, 'Error parsing cron expression');
    return false;
  }
}

// Helper function to check if a time value matches a cron part
function isTimeMatch(cronPart, timeValue) {
  if (cronPart === '*') return true;
  
  // Handle ranges like "1-5"
  if (cronPart.includes('-')) {
    const [start, end] = cronPart.split('-').map(Number);
    return timeValue >= start && timeValue <= end;
  }
  
  // Handle lists like "1,3,5"
  if (cronPart.includes(',')) {
    const values = cronPart.split(',').map(Number);
    return values.includes(timeValue);
  }
  
  // Handle single value
  return Number(cronPart) === timeValue;
}

// Enhanced message handler with flow triggers
function setupFlowTriggers(sessionId, client) {
  client.on('message', async (message) => {
    try {
      const takeover = getHumanOverride(sessionId, message.from);
      if (takeover && takeover.mode === 'all') {
        logger.info({ sessionId, chatId: message.from }, 'Human takeover active: blocking flow triggers');
        return;
      }
      // Get saved flows for this session (placeholder)
      const flows = []; // Would load from DB
      
      for (const flow of flows) {
        const triggerNode = flow.nodes.find(n => n.type === 'trigger');
        if (!triggerNode) continue;
        
        const shouldTrigger = evaluateTrigger(triggerNode, message.body, message.from, sessionId);
        if (shouldTrigger) {
          logger.info({ sessionId, flowId: flow.id, phone: message.from }, 'Flow triggered');
          // Execute flow
          await executeFlow(flow, message.from, sessionId);
        }
      }
    } catch (e) {
      logger.error({ sessionId, error: String(e) }, 'Flow trigger error');
    }
  });
}

// Execute individual node with enhanced context
async function executeNode(node, context, state) {
  const { userData, systemVars, messageData, sessionId } = context;
  
  try {
    if (node.type === 'send') {
      const msg = replaceDynamicVars(String(node.data?.message || ''), context);
      const caption = replaceDynamicVars(String(node.data?.caption || ''), context);
      const mediaPath = node.data?.mediaPath;
      
      logger.info({ sessionId, flowId: context.flowId, nodeId: node.id, message: msg, phone: userData.phone, hasMedia: !!mediaPath }, 'About to send message from flow');
      
      // Validate WhatsApp number before sending
      const validation = await validateWhatsAppNumber(state, userData.phone);
      if (!validation.valid) {
        logger.warn({ sessionId, flowId: context.flowId, nodeId: node.id, phone: userData.phone, error: validation.error }, 'Flow send failed: number validation failed');
        return; // Skip sending
      }
      
      try {
        await sendItem(state, { 
          phone: userData.phone, 
          message: msg, 
          mediaPath: mediaPath,
          caption: caption || msg
        });
        logger.info({ sessionId, flowId: context.flowId, nodeId: node.id, message: msg, phone: userData.phone }, 'Successfully sent message from flow');
      } catch (err) {
        logger.error({ sessionId, flowId: context.flowId, nodeId: node.id, message: msg, phone: userData.phone, error: String(err) }, 'Failed to send message from flow');
      }
    } else if (node.type === 'delay') {
      const sec = Math.max(0, Number(node.data?.seconds || 0));
      await sleep(sec * 1000);
    } else if (node.type === 'webhook') {
      const url = String(node.data?.url || '');
      const method = String(node.data?.method || 'POST');
      if (url) { 
        try { 
          await fetch(url, { method, body: JSON.stringify(context) }); 
        } catch {} 
      }
    } else if (node.type === 'set_variable') {
      // Set custom variables
      const varName = node.data?.variableName || '';
      const varValue = replaceDynamicVars(String(node.data?.variableValue || ''), context);
      if (varName) {
        userData[varName] = varValue;
      }
    } else if (node.type === 'tag_user') {
      // Tag user based on action
      const userTag = node.data?.userTag || '';
      const tagAction = node.data?.tagAction || 'add';
      const phone = userData.phone;
      
      if (userTag && phone) {
        if (!userTags.has(phone)) {
          userTags.set(phone, new Set());
        }
        
        const userTagSet = userTags.get(phone);
        
        switch (tagAction) {
          case 'add':
            userTagSet.add(userTag);
            logger.info({ phone, tag: userTag, action: 'add' }, 'Added tag to user');
            break;
          case 'remove':
            userTagSet.delete(userTag);
            logger.info({ phone, tag: userTag, action: 'remove' }, 'Removed tag from user');
            break;
          case 'replace':
            userTags.set(phone, new Set([userTag]));
            logger.info({ phone, tag: userTag, action: 'replace' }, 'Replaced all tags for user');
            break;
        }
        
        // Save user tags to file
        saveUserTagsToFile();
      }
    } else if (node.type === 'yes_no') {
      // Yes/No question - this would need to be handled by waiting for user response
      // For now, we'll just log the question
      logger.info({ sessionId, flowId: context.flowId, nodeId: node.id, question: node.data?.question }, 'Yes/No question asked');
    } else if (node.type === 'wait_response') {
      // Wait for user response - this would need to be handled by the flow execution system
      // For now, we'll just log the timeout
      const timeout = Math.max(5, Number(node.data?.timeout || 30));
      logger.info({ sessionId, flowId: context.flowId, nodeId: node.id, timeout }, 'Waiting for user response');
      // In a real implementation, this would pause the flow and wait for the next message
    } else if (node.type === 'redirect_flow') {
      // Redirect to another flow
      const targetFlowId = node.data?.targetFlow;
      const redirectMessage = node.data?.redirectMessage;
      
      if (targetFlowId) {
        logger.info({ sessionId, flowId: context.flowId, nodeId: node.id, targetFlowId, phone: userData.phone }, 'Redirecting user to different flow');
        
        // Send redirect message if provided
        if (redirectMessage) {
          const msg = replaceDynamicVars(String(redirectMessage), context);
          try {
            await sendItem(state, { 
              phone: userData.phone, 
              message: msg
            });
            logger.info({ sessionId, flowId: context.flowId, nodeId: node.id, message: msg, phone: userData.phone }, 'Sent redirect message');
          } catch (err) {
            logger.error({ sessionId, flowId: context.flowId, nodeId: node.id, message: msg, phone: userData.phone, error: String(err) }, 'Failed to send redirect message');
          }
        }
        
        // Store the redirect information for the flow execution system
        // This would be handled by the flow execution logic to switch to the target flow
        context.redirectToFlow = targetFlowId;
      }
    }
  } catch (err) {
    logger.warn({ sessionId, err: String(err) }, 'Node execution error');
  }
}

async function executeFlow(flow, phone, sessionId, messageData = {}) {
  const state = ensureSession(sessionId);
  if (!state || !state.isReady) return;

  // Initialize user data context
  const userData = {
    phone,
    messageCount: 0, // Would be tracked per user
    lastMessage: messageData.messageText || '',
    ...messageData
  };
  
  const systemVars = {
    sessionId,
    timestamp: new Date().toISOString()
  };
  
  const context = { userData, systemVars, messageData, sessionId, flowId: flow.id };

  const byId = new Map();
  for (const n of flow.nodes) byId.set(n.id, n);
  
  const nextOf = (id) => {
    const e = flow.edges.find((x) => x.from === id);
    return e ? byId.get(e.to) : null;
  };

  let cur = flow.nodes.find((n) => n.type === 'trigger');
  if (!cur) return;

  // If no edges defined, execute all non-trigger nodes in sequence
  if (!flow.edges || flow.edges.length === 0) {
    logger.info({ sessionId, flowId: flow.id }, 'No edges found, executing all non-trigger nodes');
    const nonTriggerNodes = flow.nodes.filter(n => n.type !== 'trigger');
    for (const node of nonTriggerNodes) {
      await executeNode(node, context, state);
    }
    return;
  }

  // Execute flow with branching logic
  while (cur) {
    try {
      if (cur.type === 'condition') {
        // Evaluate condition and branch accordingly
        const conditionType = cur.data?.conditionType || 'equals';
        const conditionValue = cur.data?.condition || '';
        const fullCondition = `${conditionType}:${conditionValue}`;
        const conditionResult = evaluateCondition(fullCondition, context);
        
        logger.info({ 
          sessionId, 
          flowId: flow.id, 
          nodeId: cur.id, 
          conditionType, 
          conditionValue, 
          fullCondition,
          result: conditionResult,
          phone: userData.phone,
          userTags: userData.phone && userTags.has(userData.phone) ? Array.from(userTags.get(userData.phone)) : []
        }, 'Evaluating condition node');
        
        const nextNodeId = conditionResult ? cur.data?.trueNode : cur.data?.falseNode;
        cur = nextNodeId ? byId.get(nextNodeId) : null;
      } else if (cur.type === 'yes_no') {
        // Yes/No question - send the question and wait for response
        const question = replaceDynamicVars(String(cur.data?.question || ''), context);
        await sendItem(state, { phone: userData.phone, message: question });
        
        // Store the flow state to resume after user response
        const flowState = {
          flowId: flow.id,
          currentNodeId: cur.id,
          context: context,
          waitingForResponse: true,
          choices: cur.data?.choices || [{ text: 'Yes', nodeId: cur.data?.yesNode }, { text: 'No', nodeId: cur.data?.noNode }],
          timestamp: Date.now()
        };
        
        // Store in a waiting flows map (in production, this would be in a database)
        if (!global.waitingFlows) global.waitingFlows = new Map();
        global.waitingFlows.set(userData.phone, flowState);
        
        logger.info({ sessionId, flowId: flow.id, phone: userData.phone, question, choices: flowState.choices }, 'Flow paused waiting for choice response');
        return; // Exit flow execution, will resume when user responds
      } else if (cur.type === 'wait_response') {
        // Wait for any response
        const timeout = Math.max(5, Number(cur.data?.timeout || 30));
        
        // Store the flow state to resume after user response or timeout
        const flowState = {
          flowId: flow.id,
          currentNodeId: cur.id,
          context: context,
          waitingForResponse: true,
          timeoutNodeId: cur.data?.timeoutNode,
          responseNodeId: cur.data?.responseNode,
          timeout: timeout * 1000, // Convert to milliseconds
          timestamp: Date.now()
        };
        
        if (!global.waitingFlows) global.waitingFlows = new Map();
        global.waitingFlows.set(userData.phone, flowState);
        
        logger.info({ sessionId, flowId: flow.id, phone: userData.phone, timeout }, 'Flow paused waiting for response');
        return; // Exit flow execution, will resume when user responds or timeout
      } else {
        await executeNode(cur, context, state);
        cur = nextOf(cur.id);
      }
    } catch (err) {
      logger.warn({ sessionId, err: String(err) }, 'Flow execution error');
      break;
    }
  }
}

// Continue flow execution from a specific node
async function continueFlowExecution(flow, startNode, context, sessionId) {
  const state = ensureSession(sessionId);
  if (!state || !state.isReady) return;

  const byId = new Map();
  for (const n of flow.nodes) byId.set(n.id, n);
  
  const nextOf = (id) => {
    const e = flow.edges.find((x) => x.from === id);
    return e ? byId.get(e.to) : null;
  };

  let cur = startNode;
  
  // Execute flow with branching logic from the starting node
  while (cur) {
    try {
      if (cur.type === 'condition') {
        // Evaluate condition and branch accordingly
        const conditionResult = evaluateCondition(cur.data?.condition || '', context);
        const nextNodeId = conditionResult ? cur.data?.trueNode : cur.data?.falseNode;
        cur = nextNodeId ? byId.get(nextNodeId) : null;
      } else if (cur.type === 'yes_no') {
        // Yes/No question - send the question and wait for response
        const question = replaceDynamicVars(String(cur.data?.question || ''), context);
        await sendItem(state, { phone: context.userData.phone, message: question });
        
        // Store the flow state to resume after user response
        const flowState = {
          flowId: flow.id,
          currentNodeId: cur.id,
          context: context,
          waitingForResponse: true,
          choices: cur.data?.choices || [{ text: 'Yes', nodeId: cur.data?.yesNode }, { text: 'No', nodeId: cur.data?.noNode }],
          timestamp: Date.now()
        };
        
        if (!global.waitingFlows) global.waitingFlows = new Map();
        global.waitingFlows.set(context.userData.phone, flowState);
        
        logger.info({ sessionId, flowId: flow.id, phone: context.userData.phone, question, choices: flowState.choices }, 'Flow paused waiting for choice response');
        return; // Exit flow execution, will resume when user responds
      } else if (cur.type === 'wait_response') {
        // Wait for any response
        const timeout = Math.max(5, Number(cur.data?.timeout || 30));
        
        // Store the flow state to resume after user response or timeout
        const flowState = {
          flowId: flow.id,
          currentNodeId: cur.id,
          context: context,
          waitingForResponse: true,
          timeoutNodeId: cur.data?.timeoutNode,
          responseNodeId: cur.data?.responseNode,
          timeout: timeout * 1000, // Convert to milliseconds
          timestamp: Date.now()
        };
        
        if (!global.waitingFlows) global.waitingFlows = new Map();
        global.waitingFlows.set(context.userData.phone, flowState);
        
        logger.info({ sessionId, flowId: flow.id, phone: context.userData.phone, timeout }, 'Flow paused waiting for response');
        return; // Exit flow execution, will resume when user responds or timeout
      } else {
        await executeNode(cur, context, state);
        cur = nextOf(cur.id);
      }
    } catch (err) {
      logger.warn({ sessionId, err: String(err) }, 'Flow execution error');
      break;
    }
  }
}

// Check flow triggers for incoming messages
async function checkFlowTriggers(message, sessionId) {
  try {
    // First, check if there's a waiting flow for this user
    if (global.waitingFlows && global.waitingFlows.has(message.from)) {
      const flowState = global.waitingFlows.get(message.from);
      const flow = savedFlows.get(flowState.flowId);
      
      if (flow) {
        logger.info({ sessionId, phone: message.from, flowId: flow.id }, 'Resuming waiting flow');
        
        // Remove from waiting flows
        global.waitingFlows.delete(message.from);
        
        // Determine next node based on response
        let nextNodeId = null;
        const responseText = (message.body || '').toLowerCase().trim();
        
        if (flowState.choices && flowState.choices.length > 0) {
          // Enhanced choice flow - match response to choices
          for (const choice of flowState.choices) {
            const choiceText = choice.text.toLowerCase();
            if (responseText.includes(choiceText) || 
                (choiceText === 'yes' && (responseText.includes('y') || responseText.includes('1'))) ||
                (choiceText === 'no' && (responseText.includes('n') || responseText.includes('0')))) {
              nextNodeId = choice.nodeId;
              break;
            }
          }
        } else if (flowState.responseNodeId) {
          // Wait response flow
          nextNodeId = flowState.responseNodeId;
        }
        
        if (nextNodeId) {
          // Resume flow execution from the next node
          const byId = new Map();
          for (const n of flow.nodes) byId.set(n.id, n);
          
          const nextNode = byId.get(nextNodeId);
          if (nextNode) {
            // Update context with new message data
            flowState.context.messageData.messageText = message.body || '';
            flowState.context.userData.lastMessage = message.body || '';
            
            // Continue execution from the next node
            await continueFlowExecution(flow, nextNode, flowState.context, sessionId);
            return true; // Flow was handled
          }
        }
      }
    }
    
    // Get saved flows for this session
    const flows = Array.from(savedFlows.values()).filter(f => f.sessionId === sessionId);
    
    logger.info({ 
      sessionId, 
      messageBody: message.body, 
      flowsCount: flows.length,
      totalFlows: savedFlows.size,
      allFlows: Array.from(savedFlows.values()).map(f => ({ id: f.id, name: f.name, sessionId: f.sessionId }))
    }, 'Checking flow triggers');
    
    let anyFlowTriggered = false;
    
    for (const flow of flows) {
      const triggerNode = flow.nodes.find(n => n.type === 'trigger');
      if (!triggerNode) {
        logger.warn({ sessionId, flowId: flow.id }, 'Flow has no trigger node');
        continue;
      }
      
      const shouldTrigger = evaluateTrigger(triggerNode, message.body, message.from, sessionId);
      logger.info({ 
        sessionId, 
        flowId: flow.id, 
        triggerType: triggerNode.data?.triggerType, 
        condition: triggerNode.data?.condition,
        shouldTrigger 
      }, 'Flow trigger evaluation');
      
      if (shouldTrigger) {
        logger.info({ sessionId, flowId: flow.id, phone: message.from }, 'Flow triggered - executing');
        anyFlowTriggered = true;
        
        // Track flow execution
        const analytics = flowAnalytics.get(flow.id) || { executions: 0, successes: 0, failures: 0, lastExecuted: null };
        analytics.executions++;
        analytics.lastExecuted = new Date().toISOString();
        flowAnalytics.set(flow.id, analytics);
        
        // Execute flow asynchronously with message data
        const messageData = {
          messageText: message.body || '',
          senderPhone: message.from || '',
          senderName: message._data?.notifyName || '',
          chatTitle: message._data?.chat?.name || '',
          hasMedia: message.hasMedia || false,
          isGroup: message.from?.includes('@g.us') || false
        };
        
        executeFlow(flow, message.from, sessionId, messageData)
          .then(() => {
            const stats = flowAnalytics.get(flow.id);
            stats.successes++;
            flowAnalytics.set(flow.id, stats);
          })
          .catch(err => {
            logger.error({ sessionId, flowId: flow.id, error: String(err) }, 'Flow execution failed');
            const stats = flowAnalytics.get(flow.id);
            stats.failures++;
            flowAnalytics.set(flow.id, stats);
          });
      }
    }
    
    return anyFlowTriggered;
  } catch (e) {
    logger.error({ sessionId, error: String(e) }, 'Flow trigger check error');
    return false;
  }
}

// Flow runner (execute a simple linear flow built in flows.html)
app.post('/api/flows/run', async (req, res) => {
  try {
    const { sessionId, phone, flow } = req.body || {};
    if (!sessionId) return res.status(400).json({ error: 'sessionId required' });
    if (!phone) return res.status(400).json({ error: 'phone required' });
    if (!flow || !Array.isArray(flow.nodes) || !Array.isArray(flow.edges)) return res.status(400).json({ error: 'flow invalid' });

    const state = ensureSession(sessionId);
    if (!state || !state.isReady) return res.status(400).json({ error: 'session not ready' });

    const byId = new Map();
    for (const n of flow.nodes) byId.set(n.id, n);
    const nextOf = (id) => {
      const e = flow.edges.find((x) => x.from === id);
      return e ? byId.get(e.to) : null;
    };
    let cur = flow.nodes.find((n) => n.type === 'trigger');
    if (!cur) return res.status(400).json({ error: 'no trigger node' });

    (async () => {
      let guard = 0;
      while (cur && guard < 500) {
        guard += 1;
        try {
          if (cur.type === 'trigger') {
            // Trigger nodes are evaluated but don't execute actions
            const triggerType = cur.data?.triggerType || 'always';
            const condition = cur.data?.condition || '';
            logger.info({ sessionId, phone, triggerType, condition }, 'Flow trigger evaluated');
          } else if (cur.type === 'send') {
            const msg = replaceSystemVars(String(cur.data?.message || ''));
            await sendItem(state, { phone, message: msg });
          } else if (cur.type === 'delay') {
            const sec = Math.max(0, Number(cur.data?.seconds || 0));
            await sleep(sec * 1000);
          } else if (cur.type === 'webhook') {
            const url = String(cur.data?.url || '');
            const method = String(cur.data?.method || 'POST');
            if (url) { try { await fetch(url, { method }); } catch {} }
          } else if (cur.type === 'condition') {
            // For now condition does not branch; evaluate for side effects/logs only
            try { Function('vars', `return (${String(cur.data?.expr || 'true')});`)({}); } catch {}
          }
        } catch (err) {
          logger.warn({ sessionId, err: String(err) }, 'Flow step error');
        }
        cur = nextOf(cur.id);
      }
    })();

    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// Export flows endpoint
app.get('/api/flows/export', (req, res) => {
  try {
    const flows = Array.from(savedFlows.values());
    const exportData = {
      version: '1.0',
      timestamp: new Date().toISOString(),
      flows: flows.map(flow => ({
        id: flow.id,
        name: flow.name,
        description: flow.description || '',
        sessionId: flow.sessionId,
        tags: flow.tags || [],
        nodes: flow.nodes,
        edges: flow.edges,
        createdAt: flow.createdAt || new Date().toISOString(),
        updatedAt: flow.updatedAt || new Date().toISOString()
      })),
      userTags: Object.fromEntries(
        Array.from(userTags.entries()).map(([phone, tags]) => [phone, Array.from(tags)])
      ),
      totalFlows: flows.length,
      totalUsers: userTags.size
    };
    
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename="flows-export-${new Date().toISOString().split('T')[0]}.json"`);
    res.json(exportData);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// Import flows endpoint
app.post('/api/flows/import', (req, res) => {
  try {
    const { flows, userTags: importedUserTags, overwrite = false } = req.body;
    
    if (!flows || !Array.isArray(flows)) {
      return res.status(400).json({ error: 'Invalid flows data' });
    }
    
    let importedCount = 0;
    let skippedCount = 0;
    let errors = [];
    
    // Import flows
    for (const flowData of flows) {
      try {
        const flowId = flowData.id;
        
        // Check if flow already exists
        if (savedFlows.has(flowId) && !overwrite) {
          skippedCount++;
          continue;
        }
        
        // Validate flow structure
        if (!flowData.name || !flowData.nodes || !Array.isArray(flowData.nodes)) {
          errors.push(`Invalid flow structure for ${flowData.name || 'unnamed flow'}`);
          continue;
        }
        
        // Create flow object
        const flow = {
          id: flowId,
          name: flowData.name,
          description: flowData.description || '',
          sessionId: flowData.sessionId || 'default',
          tags: flowData.tags || [],
          nodes: flowData.nodes,
          edges: flowData.edges || [],
          createdAt: flowData.createdAt || new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        
        // Save flow
        savedFlows.set(flowId, flow);
        importedCount++;
        
        logger.info({ flowId, flowName: flow.name }, 'Flow imported successfully');
      } catch (err) {
        errors.push(`Error importing flow ${flowData.name || 'unnamed'}: ${String(err)}`);
      }
    }
    
    // Import user tags if provided
    let importedTagsCount = 0;
    if (importedUserTags && typeof importedUserTags === 'object') {
      for (const [phone, tags] of Object.entries(importedUserTags)) {
        if (Array.isArray(tags)) {
          if (!userTags.has(phone)) {
            userTags.set(phone, new Set());
          }
          
          const userTagSet = userTags.get(phone);
          tags.forEach(tag => userTagSet.add(tag));
          importedTagsCount++;
        }
      }
      
      // Save user tags to file
      if (importedTagsCount > 0) {
        saveUserTagsToFile();
      }
    }
    
    // Save flows to file
    saveFlowsToFile();
    
    res.json({
      success: true,
      importedFlows: importedCount,
      skippedFlows: skippedCount,
      importedTags: importedTagsCount,
      errors: errors,
      message: `Successfully imported ${importedCount} flows and ${importedTagsCount} user tags`
    });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// AI Flow generator endpoint
app.post('/api/flows/generate', async (req, res) => {
  try {
    const { idea, sessionId, save = false, name: givenName, model: userModel, temperature: userTemp } = req.body || {};
    if (!idea || typeof idea !== 'string' || idea.trim().length === 0) {
      return res.status(400).json({ error: 'idea required' });
    }

    function coerceArray(value) {
      if (!value) return [];
      if (Array.isArray(value)) return value;
      if (typeof value === 'string') return value.split(',').map(s => s.trim()).filter(Boolean);
      return [];
    }

    function layoutNodes(nodes) {
      // Ensure positions if missing; lay out horizontally with spacing
      const withPos = [];
      let x = 120;
      let y = 120;
      const dx = 180;
      const dy = 100;
      let rowCount = 0;
      for (const n of nodes) {
        const nx = Number.isFinite(Number(n.x)) ? Number(n.x) : x;
        const ny = Number.isFinite(Number(n.y)) ? Number(n.y) : y;
        withPos.push({ id: String(n.id), type: String(n.type), x: nx, y: ny, data: n.data || {} });
        x += dx; rowCount += 1; if (rowCount % 4 === 0) { x = 120; y += dy; }
      }
      return withPos;
    }

    function normalizeFlowStruct(raw) {
      const out = { name: String(raw?.name || givenName || 'AI Flow'), sessionId: sessionId || raw?.sessionId || 'default', tags: coerceArray(raw?.tags), nodes: [], edges: [] };
      const nodes = Array.isArray(raw?.nodes) ? raw.nodes : [];
      const edges = Array.isArray(raw?.edges) ? raw.edges : [];

      // Normalize nodes
      const normalizedNodes = nodes.map((n, idx) => {
        const id = String(n?.id || `node_${idx + 1}`);
        const type = String(n?.type || 'send');
        const data = { ...(n?.data || {}) };
        // Map possible alternative keys from LLM
        if (type === 'trigger') {
          if (!data.triggerType && n?.triggerType) data.triggerType = n.triggerType;
          if (!data.condition && n?.condition) data.condition = n.condition;
          if (!data.description && n?.description) data.description = n.description;
          if (!data.triggerType) data.triggerType = 'always';
        }
        if (type === 'condition') {
          if (!data.conditionType && (n?.conditionType || n?.condition?.type)) data.conditionType = n?.conditionType || n?.condition?.type;
          if (!data.condition && (n?.condition || n?.condition?.value)) data.condition = n?.condition?.value || n?.condition;
          if (!data.trueNode && (n?.trueNode || n?.onTrue)) data.trueNode = n?.trueNode || n?.onTrue;
          if (!data.falseNode && (n?.falseNode || n?.onFalse)) data.falseNode = n?.falseNode || n?.onFalse;
          if (!data.conditionType) data.conditionType = 'equals';
          if (!data.condition) data.condition = 'equals:dummy:true';
        }
        if (type === 'send') {
          if (!data.message && (n?.message || n?.text)) data.message = n?.message || n?.text;
          if (!data.message) data.message = 'Hello!';
        }
        if (type === 'delay') {
          if (data.seconds == null && (n?.seconds != null)) data.seconds = Number(n.seconds) || 1;
          if (data.seconds == null) data.seconds = 1;
        }
        if (type === 'webhook') {
          if (!data.url && n?.url) data.url = n.url;
          if (!data.method && n?.method) data.method = n.method;
          if (!data.method) data.method = 'POST';
        }
        return { id, type, x: n?.x, y: n?.y, data };
      });

      // Guarantee a trigger exists
      if (!normalizedNodes.some(n => n.type === 'trigger')) {
        normalizedNodes.unshift({ id: 'node_1', type: 'trigger', x: 120, y: 120, data: { triggerType: 'always', condition: '' } });
        // Renumber other nodes if id clash
        let i = 2;
        for (let k = 1; k < normalizedNodes.length; k++) {
          if (!normalizedNodes[k].id || normalizedNodes[k].id === 'node_1') normalizedNodes[k].id = `node_${i++}`;
        }
      }

      // Normalize edges
      const normalizedEdges = edges
        .map(e => ({ from: String(e?.from || e?.source || ''), to: String(e?.to || e?.target || '') }))
        .filter(e => e.from && e.to);

      out.nodes = layoutNodes(normalizedNodes);
      out.edges = normalizedEdges;
      return out;
    }

    // If OpenAI key available, attempt LLM generation
    const apiKey = agentMgr.getApiKey();
    let llmFlow = null;
    let modelUsed = null;
    if (apiKey) {
      try {
        const sys = `You generate WhatsApp flow graphs for an internal flow builder. Output MUST be valid JSON with keys name, tags, nodes, edges. Schema:
nodes: Array<{ id: string, type: 'trigger'|'send'|'delay'|'condition'|'set_variable'|'tag_user'|'yes_no'|'wait_response'|'redirect_flow'|'webhook', x?: number, y?: number, data: object }>
For trigger: data.triggerType ('keyword'|'always'|'cron'), data.condition (string).
For send: data.message (string).
For delay: data.seconds (number).
For condition: data.conditionType ('equals'|'contains'|'greater_than'|'less_than'|'has_tag'|'has_any_tag'|'has_all_tags'|'time_between'|'day_of_week'|'message_count'|'has_media'|'is_group'), data.condition (string), data.trueNode (node id), data.falseNode (node id).
edges: Array<{ from: nodeId, to: nodeId }>. Always include a single trigger node. Keep it simple and robust.`;
        const user = `Build a small flow for this idea:
"""
${idea}
"""
Session: ${sessionId || 'default'}
Return only JSON.`;
        const model = String(userModel || 'gpt-4o-mini');
        const temperature = Math.max(0, Math.min(1, Number(userTemp ?? 0.2)));
        const resp = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
          body: JSON.stringify({ model, temperature, messages: [ { role: 'system', content: sys }, { role: 'user', content: user } ], response_format: { type: 'json_object' } })
        });
        if (resp.ok) {
          const data = await resp.json();
          const content = data.choices?.[0]?.message?.content || '{}';
          try { llmFlow = JSON.parse(content); } catch {}
          try { modelUsed = data.model || model; } catch { modelUsed = model; }
        }
      } catch (e) {
        logger.warn({ error: String(e) }, 'LLM flow generation failed');
      }
    }

    let flowStruct = null;
    if (llmFlow) {
      flowStruct = normalizeFlowStruct(llmFlow);
    } else {
      // Fallback deterministic simple flow
      const keywords = idea.toLowerCase().match(/[a-z]{3,}/g)?.slice(0, 5) || [];
      const triggerCond = keywords.length ? keywords.join(',') : '';
      const fallback = {
        name: givenName || 'AI Flow',
        sessionId: sessionId || 'default',
        tags: [],
        nodes: [
          { id: 'node_1', type: 'trigger', data: { triggerType: triggerCond ? 'keyword' : 'always', condition: triggerCond } },
          { id: 'node_2', type: 'send', data: { message: `Hi! This flow was generated from your idea: "${idea.slice(0, 120)}"` } }
        ],
        edges: [ { from: 'node_1', to: 'node_2' } ]
      };
      flowStruct = normalizeFlowStruct(fallback);
    }

    if (save) {
      const flow = {
        id: Date.now().toString(),
        name: flowStruct.name,
        sessionId: flowStruct.sessionId,
        tags: flowStruct.tags,
        nodes: flowStruct.nodes,
        edges: flowStruct.edges,
        createdAt: new Date().toISOString()
      };
      savedFlows.set(flow.id, flow);
      saveFlowsToFile();
      return res.json({ ok: true, saved: true, modelUsed: modelUsed || null, flow });
    }

    res.json({ ok: true, saved: false, modelUsed: modelUsed || null, flow: { name: flowStruct.name, sessionId: flowStruct.sessionId, tags: flowStruct.tags, nodes: flowStruct.nodes, edges: flowStruct.edges } });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// AI: suggest keyword expansions for triggers
app.post('/api/flows/keywords', async (req, res) => {
  try {
    const { seed, max = 20, model: userModel } = req.body || {};
    const base = String(seed || '').trim();
    if (!base) return res.status(400).json({ error: 'seed required (comma-separated keywords)' });
    const apiKey = agentMgr.getApiKey();
    let modelUsed = null;
    if (apiKey) {
      try {
        const model = String(userModel || 'gpt-4o-mini');
        const sys = 'Expand trigger keywords for WhatsApp flows. Return JSON: {"suggestions": ["word1","word2",...]} with unique, lowercase, short tokens (1-2 words), no punctuation.';
        const user = `Seed: ${base}\nLimit: ${max}`;
        const resp = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
          body: JSON.stringify({ model, temperature: 0.3, messages: [ { role: 'system', content: sys }, { role: 'user', content: user } ], response_format: { type: 'json_object' } })
        });
        if (resp.ok) {
          const data = await resp.json();
          modelUsed = data.model || model;
          const content = data.choices?.[0]?.message?.content || '{}';
          const json = JSON.parse(content);
          const suggestions = Array.isArray(json?.suggestions) ? json.suggestions : [];
          return res.json({ ok: true, modelUsed, suggestions });
        }
      } catch (e) {
        logger.warn({ error: String(e) }, 'Keyword expansion via LLM failed');
      }
    }
    // Fallback: simple expansions (dedupe + stemming-ish)
    const parts = base.split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
    const extra = new Set();
    for (const p of parts) {
      extra.add(p);
      if (p.endsWith('s')) extra.add(p.slice(0, -1)); else extra.add(p + 's');
    }
    return res.json({ ok: true, modelUsed, suggestions: Array.from(extra).slice(0, Number(max) || 20) });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// AI: explain a flow (summary and per-node/path notes)
app.post('/api/flows/explain', async (req, res) => {
  try {
    const { flowId, flow: flowBody, model: userModel } = req.body || {};
    let flow = null;
    if (flowId) flow = savedFlows.get(String(flowId));
    if (!flow && flowBody && Array.isArray(flowBody.nodes) && Array.isArray(flowBody.edges)) flow = flowBody;
    if (!flow) return res.status(400).json({ error: 'flowId or flow required' });

    const apiKey = agentMgr.getApiKey();
    let modelUsed = null;
    if (apiKey) {
      try {
        const model = String(userModel || 'gpt-4o-mini');
        const sys = 'Explain a WhatsApp automation flow clearly and concisely for non-technical users. Return Markdown.';
        const user = `Name: ${flow.name || 'Untitled'}\nSession: ${flow.sessionId || 'default'}\nNodes: ${JSON.stringify(flow.nodes)}\nEdges: ${JSON.stringify(flow.edges)}\nPlease include: 1) one-paragraph summary, 2) node-by-node explanation with IDs and key fields (triggerType/condition, message, seconds, etc.), 3) describe branches from condition nodes, 4) potential risks (missing nodes, dangling edges, multiple triggers).`;
        const resp = await fetch('https://api/openai.com/v1/chat/completions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
          body: JSON.stringify({ model, temperature: 0.2, messages: [ { role: 'system', content: sys }, { role: 'user', content: user } ] })
        });
        if (resp.ok) {
          const data = await resp.json();
          modelUsed = data.model || model;
          const content = data.choices?.[0]?.message?.content || '';
          return res.json({ ok: true, modelUsed, explanation: content || '' });
        }
      } catch (e) {
        logger.warn({ error: String(e) }, 'Flow explanation via LLM failed');
      }
    }
    // Fallback: generate basic explanation
    const byId = new Map();
    for (const n of (flow.nodes || [])) byId.set(n.id, n);
    const lines = [];
    lines.push(`# ${flow.name || 'Flow'}\n`);
    lines.push(`Session: ${flow.sessionId || 'default'}\n`);
    const triggers = (flow.nodes || []).filter(n => n.type === 'trigger');
    if (triggers.length > 1) lines.push(`Warning: multiple triggers (${triggers.length}).`);
    if (triggers.length === 0) lines.push('Warning: no trigger node.');
    lines.push('## Nodes');
    for (const n of (flow.nodes || [])) {
      lines.push(`- ${n.id} [${n.type}] ${JSON.stringify(n.data || {})}`);
    }
    lines.push('\n## Edges');
    for (const e of (flow.edges || [])) lines.push(`- ${e.from} -> ${e.to}`);
    // Dangling edges
    const missing = (flow.edges || []).filter(e => !byId.has(e.from) || !byId.has(e.to));
    if (missing.length) lines.push(`\nWarning: dangling edges: ${JSON.stringify(missing)}`);
    return res.json({ ok: true, modelUsed, explanation: lines.join('\n') });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// Export single flow endpoint
app.get('/api/flows/export/:flowId', (req, res) => {
  try {
    const { flowId } = req.params;
    const flow = savedFlows.get(flowId);
    
    if (!flow) {
      return res.status(404).json({ error: 'Flow not found' });
    }
    
    const exportData = {
      version: '1.0',
      timestamp: new Date().toISOString(),
      flows: [{
        id: flow.id,
        name: flow.name,
        description: flow.description || '',
        sessionId: flow.sessionId,
        tags: flow.tags || [],
        nodes: flow.nodes,
        edges: flow.edges,
        createdAt: flow.createdAt || new Date().toISOString(),
        updatedAt: flow.updatedAt || new Date().toISOString()
      }],
      totalFlows: 1
    };
    
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename="flow-${flow.name.replace(/[^a-zA-Z0-9]/g, '_')}-${new Date().toISOString().split('T')[0]}.json"`);
    res.json(exportData);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// Debug endpoint to test flow execution
app.post('/api/flows/debug/:flowId', async (req, res) => {
  try {
    const { flowId } = req.params;
    const { phone, sessionId } = req.body;
    
    const flow = savedFlows.get(flowId);
    if (!flow) {
      return res.status(404).json({ error: 'Flow not found' });
    }
    
    const state = sessions.get(sessionId);
    if (!state || !state.isReady) {
      return res.status(400).json({ error: 'Session not ready' });
    }
    
    // Initialize user data context
    const userData = {
      phone,
      messageCount: 0,
      lastMessage: '',
    };
    
    const systemVars = {
      sessionId,
      timestamp: new Date().toISOString()
    };
    
    const messageData = {
      messageText: 'Debug test message',
      sender_name: 'Debug User',
      sender_phone: phone,
      chat_title: 'Debug Chat',
      isCronTrigger: false,
      triggerTime: new Date().toISOString()
    };
    
    const context = { userData, systemVars, messageData, sessionId, flowId: flow.id };
    
    // Check user tags
    const userTagsInfo = userTags.has(phone) ? Array.from(userTags.get(phone)) : [];
    
    // Test condition evaluation
    const conditionNodes = flow.nodes.filter(n => n.type === 'condition');
    const conditionResults = conditionNodes.map(node => {
      const conditionType = node.data?.conditionType || 'equals';
      const conditionValue = node.data?.condition || '';
      const fullCondition = `${conditionType}:${conditionValue}`;
      const result = evaluateCondition(fullCondition, context);
      
      return {
        nodeId: node.id,
        conditionType,
        conditionValue,
        fullCondition,
        result,
        trueNode: node.data?.trueNode,
        falseNode: node.data?.falseNode
      };
    });
    
    res.json({
      flowId,
      flowName: flow.name,
      phone,
      userTags: userTagsInfo,
      conditionResults,
      context: {
        userData,
        systemVars,
        messageData
      }
    });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// Auto-suggest templates from successful sends
app.get('/api/templates/suggestions', (req, res) => {
  try {
    const limit = Math.min(Number(req.query.limit) || 20, 50);
    const templates = queue.getSuccessfulTemplates(limit);
    res.json({ templates });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// Chat analysis endpoints
app.post('/api/chat/analyze', async (req, res) => {
  try {
    const { sessionId, chatId } = req.body || {};
    if (!sessionId || !chatId) return res.status(400).json({ error: 'sessionId and chatId required' });
    
    const state = ensureSession(sessionId);
    if (!state || !state.isReady) return res.status(400).json({ error: 'session not ready' });
    
    const chat = await state.client.getChatById(chatId);
    const messages = await chat.fetchMessages({ limit: 25 });
    
    const analysis = await agent.analyzeChat(chatId, sessionId, messages);
    res.json({ analysis });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

app.get('/api/chat/analysis/:sessionId/:chatId', (req, res) => {
  try {
    const { sessionId, chatId } = req.params;
    const analysis = agent.getChatAnalysis(chatId, sessionId);
    res.json({ analysis });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// KB Quality Dashboard
app.get('/api/kb/quality', (req, res) => {
  try {
    const { sessionId } = req.query || {};
    const quality = agentMgr.getKBQuality(sessionId || 'default');
    res.json(quality);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// Templates API
app.get('/api/templates', (_req, res) => {
  res.json({ templates: loadTemplates() });
});

app.post('/api/templates', (req, res) => {
  const { name, message, caption } = req.body || {};
  if (!name) return res.status(400).json({ error: 'name required' });
  const list = loadTemplates();
  const id = `tpl_${Date.now()}`;
  list.push({ id, name, message: message || '', caption: caption || '' });
  saveTemplates(list);
  res.json({ id });
});

app.put('/api/templates/:id', (req, res) => {
  const id = req.params.id;
  const { name, message, caption } = req.body || {};
  const list = loadTemplates();
  const idx = list.findIndex(t => t.id === id);
  if (idx === -1) return res.status(404).json({ error: 'not found' });
  list[idx] = { ...list[idx], name: name ?? list[idx].name, message: message ?? list[idx].message, caption: caption ?? list[idx].caption };
  saveTemplates(list);
  res.json({ ok: true });
});

app.delete('/api/templates/:id', (req, res) => {
  const id = req.params.id;
  const list = loadTemplates().filter(t => t.id !== id);
  saveTemplates(list);
  res.json({ ok: true });
});

app.post('/api/campaign/start', async (req, res) => {
  const { sessionId, items, delayMs, startTime, window, retries, throttle, autoShard, perSessionCap, validateNumbers } = req.body || {};
  if (!Array.isArray(items) || items.length === 0) return res.status(400).json({ error: 'items required' });

  // Pre-send dedupe and validation
  const normalizePhone = (p) => String(p || '').replace(/[^0-9]/g, '');
  const seen = new Set();
  const valid = [];
  const invalid = [];
  for (const it of items) {
    const phone = normalizePhone(it.phone);
    if (!phone || phone.length < 6) { invalid.push(it); continue; }
    if (seen.has(phone)) continue; // dedupe
    seen.add(phone);
    valid.push({ ...it, phone });
  }
  if (!valid.length) return res.status(400).json({ error: 'no valid phone numbers' });

  const delay = Number(delayMs) || 1000;
  const common = { delayMs: delay, startTime: startTime || null, window: window || {}, retries: retries || {}, throttle: throttle || {}, validateNumbers: validateNumbers !== false };
  const id = `cmp_${Date.now()}`;

  // Shard across sessions or use a single session
  let targets = {};
  if (autoShard) {
    const readySessions = Array.from(sessions.entries()).filter(([, s]) => s.isReady).map(([id]) => id);
    if (!readySessions.length) return res.status(400).json({ error: 'no ready sessions' });
    const cap = Math.max(0, Number(perSessionCap) || 0);
    targets = Object.fromEntries(readySessions.map(id => [id, []]));
    let idx = 0;
    for (const it of valid) {
      let placed = false;
      for (let r = 0; r < readySessions.length; r += 1) {
        const sid = readySessions[(idx + r) % readySessions.length];
        if (cap && targets[sid].length >= cap) continue;
        targets[sid].push(it);
        idx += 1; placed = true; break;
      }
      if (!placed) break; // all caps reached
    }
  } else {
    if (!sessionId) return res.status(400).json({ error: 'sessionId required' });
    const state = sessions.get(sessionId);
    if (!state || !state.isReady) return res.status(400).json({ error: 'WhatsApp not ready' });
    targets = { [sessionId]: valid };
  }

  queue.enqueueCampaign({ id, itemsBySession: targets, common });

  res.json({ id, status: 'queued', valid: valid.length, invalid: invalid.length, sessions: Object.keys(targets).length });
});

app.post('/api/campaign/cancel', (req, res) => {
  const { sessionId } = req.body || {};
  if (!sessionId) return res.json({ ok: true });
  const state = sessions.get(sessionId);
  if (!state) return res.json({ ok: true });
  // Stop worker loop immediately
  const worker = workers.get(sessionId);
  if (worker) worker.running = false;
  // Cancel pending jobs for this session (and campaign if known)
  let cancelled = 0;
  if (state.currentCampaign?.id) {
    const res1 = queue.cancelPendingJobs({ campaignId: state.currentCampaign.id, reason: 'cancelled by user' });
    cancelled += res1.cancelled;
  }
  const res2 = queue.cancelPendingJobs({ sessionId, reason: 'cancelled by user' });
  cancelled += res2.cancelled;
  const id = state.currentCampaign?.id || 'unknown';
  state.currentCampaign = null;
  io.to(getRoom(sessionId)).emit('campaign_status', { sessionId, id, status: 'cancelled', cancelled });
  return res.json({ ok: true, cancelled });
});

// Delete/clear a specific campaign completely
app.delete('/api/campaign/:id', (req, res) => {
  const { id } = req.params;
  if (!id) return res.status(400).json({ error: 'Campaign ID required' });
  
  try {
    const result = queue.deleteCampaign(id);
    logger.info({ campaignId: id, deletedJobs: result.deletedJobs, deletedCampaigns: result.deletedCampaigns }, 'Campaign deleted');
    res.json({ 
      ok: true, 
      campaignId: id,
      deletedJobs: result.deletedJobs,
      deletedCampaigns: result.deletedCampaigns,
      message: `Campaign ${id} deleted: ${result.deletedJobs} jobs and ${result.deletedCampaigns} campaign records removed`
    });
  } catch (error) {
    logger.error({ campaignId: id, error: error.message }, 'Failed to delete campaign');
    res.status(500).json({ error: 'Failed to delete campaign', details: error.message });
  }
});

// Minimal dashboard
app.get('/', (_req, res) => {
  res.sendFile(path.join(__dirname, '../client/public/index.html'));
});

// Auto-reply CRUD
app.get('/api/auto-reply', (_req, res) => {
  res.json({ rules: autoReply.list() });
});

// AI Agent KB & settings
app.get('/api/agent/settings', (_req, res) => {
  res.json(agentMgr.getSettings());
});
app.post('/api/agent/settings', (req, res) => {
  const { enabled, prompt, apiKey } = req.body || {};
  res.json(agentMgr.updateSettings({ enabled: Boolean(enabled), prompt: prompt || '', apiKey }));
});
app.get('/api/agent/docs', (req, res) => {
  const { sessionId } = req.query || {};
  res.json({ docs: agentMgr.listDocs(sessionId || 'default') });
});
app.post('/api/agent/docs', (req, res) => {
  const { content, sessionId } = req.body || {};
  if (!content) return res.status(400).json({ error: 'content required' });
  res.json(agentMgr.addDoc(content, null, sessionId || 'default'));
});
app.delete('/api/agent/docs/:id', (req, res) => {
  agentMgr.deleteDoc(Number(req.params.id));
  res.json({ ok: true });
});

// Upload and ingest a file into KB (txt or pdf)
async function ingestDocumentFile(absPath, sessionId = 'default') {
  const m = mime.lookup(absPath) || '';
  let text = '';
  if (String(m).includes('pdf')) {
    const pdf = (await import('pdf-parse')).default;
    const data = await pdf(fs.readFileSync(absPath));
    text = data.text || '';
  } else if (String(m).includes('officedocument') || absPath.endsWith('.docx')) {
    const mammoth = (await import('mammoth')).default;
    const out = await mammoth.extractRawText({ path: absPath });
    text = out.value || '';
  } else if (String(m).includes('markdown') || absPath.endsWith('.md')) {
    text = fs.readFileSync(absPath, 'utf8');
  } else if (absPath.endsWith('.txt')) {
    text = fs.readFileSync(absPath, 'utf8');
  } else {
    // Unsupported type for KB ingestion
    return { added: 0 };
  }
  text = String(text || '').trim();
  if (!text) return { added: 0 };
  // chunk by headings where possible, then by size (~1500 chars)
  const lines = text.split(/\r?\n/);
  const groups = [];
  let buf = '';
  for (const ln of lines) {
    if (/^#{1,6}\s+|^\d+\.\s+|^[A-Z][A-Z\s]{5,}$/.test(ln)) {
      if (buf.trim().length) groups.push(buf.trim());
      buf = ln + '\n';
    } else {
      buf += ln + '\n';
    }
  }
  if (buf.trim().length) groups.push(buf.trim());
  const rawChunks = groups.length ? groups : [text];
  const chunks = [];
  for (const g of rawChunks) {
    if (g.length <= 1600) { chunks.push(g); continue; }
    for (let i=0;i<g.length;i+=1600) chunks.push(g.slice(i, i+1600));
  }
  const apiKey = agentMgr.getApiKey();
  let embeds = [];
  if (apiKey) {
    try {
      const resEmb = await fetch('https://api.openai.com/v1/embeddings', { method:'POST', headers:{'Content-Type':'application/json','Authorization':`Bearer ${apiKey}`}, body: JSON.stringify({ model:'text-embedding-3-small', input: chunks }) });
      if (resEmb.ok) {
        const data = await resEmb.json();
        embeds = data.data?.map(d => d.embedding) || [];
      }
    } catch {}
  }
  let added = 0;
  for (let i=0;i<chunks.length;i++) {
    let embedBuf = null;
    if (embeds[i]) {
      const f32 = new Float32Array(embeds[i]);
      embedBuf = Buffer.from(f32.buffer);
    }
    agentMgr.addDoc(chunks[i], embedBuf, sessionId || 'default');
    added++;
  }
  return { added };
}

app.post('/api/agent/docs/upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file' });
    const { sessionId } = req.body || {};
    const filename = req.file.filename;
    const absPath = path.join(UPLOAD_DIR, filename);
    const out = await ingestDocumentFile(absPath, sessionId || 'default');
    res.json({ ...out, filename });
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

// Background watcher to auto-ingest future KB docs dropped into uploads/
const processedKB = new Set();
function isKBFileName(name) { return /\.(txt|md|pdf|docx)$/i.test(String(name||'')); }
try {
  fs.watch(UPLOAD_DIR, { persistent: true }, async (eventType, filename) => {
    try {
      if (!filename || !isKBFileName(filename)) return;
      const absPath = path.join(UPLOAD_DIR, filename);
      if (processedKB.has(absPath)) return;
      // Defer a bit to ensure file is fully written
      setTimeout(async () => {
        try {
          if (!fs.existsSync(absPath)) return;
          const { added } = await ingestDocumentFile(absPath, 'default');
          if (added > 0) {
            processedKB.add(absPath);
            try { logger.info({ filename, added }, 'Auto-ingested KB document'); } catch {}
          }
        } catch {}
      }, 500);
    } catch {}
  });
} catch {}

// Manual rescan endpoint to ingest any existing files in uploads/
app.post('/api/agent/docs/rescan', async (_req, res) => {
  try {
    let total = 0;
    for (const name of fs.readdirSync(UPLOAD_DIR)) {
      const absPath = path.join(UPLOAD_DIR, name);
      try {
        if (fs.statSync(absPath).isFile() && isKBFileName(name)) {
          const { added } = await ingestDocumentFile(absPath, 'default');
          if (added > 0) total += added;
        }
      } catch {}
    }
    res.json({ added: total });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// Session prompt overrides
app.get('/api/agent/session-prompts', (_req, res) => { res.json({ prompts: agentMgr.listSessionPrompts() }); });
app.post('/api/agent/session-prompts', (req, res) => {
  const { sessionId, prompt, enabled } = req.body || {};
  if (!sessionId) return res.status(400).json({ error: 'sessionId required' });
  res.json(agentMgr.upsertSessionPrompt(sessionId, prompt || '', enabled !== false));
});
app.delete('/api/agent/session-prompts/:sessionId', (req, res) => {
  res.json(agentMgr.deleteSessionPrompt(req.params.sessionId));
});

// Human takeover APIs
app.post('/api/takeover/start', (req, res) => {
  try {
    const { sessionId, chatId, minutes = 15, mode = 'all' } = req.body || {};
    if (!sessionId || !chatId) return res.status(400).json({ error: 'sessionId and chatId required' });
    setHumanOverride(sessionId, chatId, minutes, mode);
    res.json({ ok: true, until: getHumanOverride(sessionId, chatId)?.until || null, mode });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});
app.post('/api/takeover/stop', (req, res) => {
  try {
    const { sessionId, chatId } = req.body || {};
    if (!sessionId || !chatId) return res.status(400).json({ error: 'sessionId and chatId required' });
    clearHumanOverride(sessionId, chatId);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});
app.get('/api/takeover/status', (req, res) => {
  try {
    const { sessionId, chatId } = req.query || {};
    if (!sessionId || !chatId) return res.status(400).json({ error: 'sessionId and chatId required' });
    const o = getHumanOverride(String(sessionId), String(chatId));
    res.json({ active: Boolean(o), until: o?.until || null, mode: o?.mode || null });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

// Extractor: scan chats/messages to collect numbers
function normalizePhone(p) { return String(p || '').replace(/[^0-9]/g, ''); }
function addNum(set, p) { const n = normalizePhone(p); if (n && n.length >= 6) set.add(n); }

app.post('/api/extract/scan', async (req, res) => {
  try {
    const { sessionId, samplePerChat } = req.body || {};
    if (!sessionId) return res.status(400).json({ error: 'sessionId required' });
    const state = sessions.get(sessionId);
    if (!state || !state.isReady) return res.status(400).json({ error: 'session not ready' });
    const client = state.client;
    const chats = await client.getChats();
    const rowKeySet = new Set();
    const rows = [];
    const limit = Math.max(0, parseInt(samplePerChat || 30, 10));
    for (const chat of chats) {
      try {
        // chat info
        const jid = chat?.id?._serialized || '';
        const user = chat?.id?.user || '';
        const chatTitle = chat?.name || chat?.formattedTitle || user || jid;
        const type = chat?.isGroup ? 'group' : 'private';
        const displayName = chat?.contact?.name || chat?.contact?.pushname || '';
        // chat JID/peer
        const phoneFromChat = normalizePhone(user || jid);
        if (phoneFromChat && phoneFromChat.length >= 6) {
          const key = `${phoneFromChat}|chat|${chatTitle}`;
          if (!rowKeySet.has(key)) { rowKeySet.add(key); rows.push({ phone: phoneFromChat, type, source: 'chat', chat_title: chatTitle, chat_id: jid, name: displayName }); }
        }
        // group participants
        if (chat.isGroup && chat.groupMetadata && Array.isArray(chat.groupMetadata.participants)) {
          for (const p of chat.groupMetadata.participants) {
            const pn = normalizePhone(p?.id?.user || '');
            if (pn && pn.length >= 6) {
              const key = `${pn}|participant|${chatTitle}`;
              if (!rowKeySet.has(key)) { rowKeySet.add(key); rows.push({ phone: pn, type, source: 'participant', chat_title: chatTitle, chat_id: jid, name: '' }); }
            }
          }
        }
        if (limit > 0 && typeof chat.fetchMessages === 'function') {
          const msgs = await chat.fetchMessages({ limit });
          for (const m of msgs) {
            const body = String(m?.body || '');
            if (!body) continue;
            const matches = body.match(/\+?\d[\d\s\-()]{5,}/g);
            if (Array.isArray(matches)) {
              for (const raw of matches) {
                const pn = normalizePhone(raw);
                if (pn && pn.length >= 6) {
                  const key = `${pn}|message|${chatTitle}`;
                  if (!rowKeySet.has(key)) { rowKeySet.add(key); rows.push({ phone: pn, type, source: 'message', chat_title: chatTitle, chat_id: jid, name: '' }); }
                }
              }
            }
          }
        }
      } catch {}
    }
    const id = `extract_${Date.now()}`;
    const unique = new Set(rows.map(r=>r.phone)).size;
    extractResults.set(id, { createdAt: new Date().toISOString(), sessionId, rows, unique });
    res.json({ id, total: unique });
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

app.get('/api/extract/result/:id', (req, res) => {
  const r = extractResults.get(req.params.id);
  if (!r) return res.status(404).json({ error: 'not found' });
  res.json(r);
});

app.get('/api/extract/export/:id.csv', (req, res) => {
  const r = extractResults.get(req.params.id);
  if (!r) return res.status(404).send('not found');
  const lines = ['phone,source,type,chat_title,chat_id,name'];
  for (const row of r.rows) {
    const esc = (s)=>`"${String(s||'').replace(/"/g,'""')}"`;
    lines.push([row.phone, row.source, row.type, esc(row.chat_title), esc(row.chat_id), esc(row.name)].join(','));
  }
  const csv = lines.join('\n');
  res.set('Content-Type', 'text/csv');
  res.set('Content-Disposition', `attachment; filename="${req.params.id}.csv"`);
  res.send(csv);
});

// Insights
app.get('/api/insights', (req, res) => {
  const days = Number(req.query.days) || 7;
  const sessionId = req.query.sessionId || undefined;
  try { res.json(queue.insights(days, sessionId)); } catch (err) { res.status(500).json({ error: String(err) }); }
});

// Recent error logs for insights
app.get('/api/insights/errors', (req, res) => {
  try {
    const days = Number(req.query.days) || 7;
    const limit = Math.min(Number(req.query.limit) || 50, 500);
    const sessionId = req.query.sessionId || undefined;
    const rows = queue.recentErrors(days, limit, sessionId);
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// CSV export for recent errors
app.get('/api/insights/errors.csv', (req, res) => {
  try {
    const days = Number(req.query.days) || 7;
    const limit = Math.min(Number(req.query.limit) || 500, 2000);
    const sessionId = req.query.sessionId || undefined;
    const rows = queue.recentErrors(days, limit, sessionId);
    const header = ['ts','session_id','phone','error'];
    const lines = [header.join(',')];
    for (const r of rows) {
      const err = (r.error || '').toString().replaceAll('\n',' ').replaceAll('"','""');
      lines.push([r.ts, r.session_id, r.phone, `"${err}"`].join(','));
    }
    const csv = lines.join('\n');
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="error-logs.csv"');
    res.send(csv);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// Backup: zip data/ and uploads/
app.get('/api/backup.zip', async (req, res) => {
  try {
    res.set('Content-Type', 'application/zip');
    res.set('Content-Disposition', 'attachment; filename="backup.zip"');
    const archive = archiver('zip', { zlib: { level: 9 } });
    archive.on('error', (err) => { try { res.status(500).end(String(err)); } catch {} });
    archive.pipe(res);
    if (fs.existsSync(DATA_DIR)) archive.directory(DATA_DIR, 'data');
    if (fs.existsSync(UPLOAD_DIR)) archive.directory(UPLOAD_DIR, 'uploads');
    await archive.finalize();
  } catch (err) {
    res.status(500).send(String(err));
  }
});

// Restore: upload zip and extract into project root (data/, uploads/)
app.post('/api/restore', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file' });
    const abs = path.join(UPLOAD_DIR, req.file.filename);
    await fs.createReadStream(abs).pipe(unzipper.Extract({ path: '.' })).promise();
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});
app.post('/api/auto-reply', (req, res) => {
  const { name, sessionId, matchType, pattern, response, mediaPath, windowStart, windowEnd, enabled } = req.body || {};
  if (!name || !matchType || !pattern) return res.status(400).json({ error: 'name, matchType, pattern required' });
  const info = autoReply.create({ name, session_id: sessionId || null, match_type: matchType, pattern, response: response || '', media_path: mediaPath || null, window_start: windowStart || null, window_end: windowEnd || null, enabled: enabled ? 1 : 0 });
  res.json(info);
});
app.put('/api/auto-reply/:id', (req, res) => {
  try {
    const id = Number(req.params.id);
    const body = req.body || {};
    const existing = (autoReply.list() || []).find(r => Number(r.id) === id);
    if (!existing) return res.status(404).json({ error: 'Rule not found' });
    const merged = {
      name: body.name ?? existing.name,
      session_id: body.sessionId ?? existing.session_id ?? null,
      match_type: body.matchType ?? existing.match_type,
      pattern: body.pattern ?? existing.pattern,
      response: body.response ?? existing.response ?? '',
      media_path: body.mediaPath ?? existing.media_path ?? null,
      window_start: body.windowStart ?? existing.window_start ?? null,
      window_end: body.windowEnd ?? existing.window_end ?? null,
      enabled: body.enabled !== undefined ? (body.enabled ? 1 : 0) : existing.enabled,
    };
    // Basic validation to avoid NOT NULL failures
    if (!merged.name || !merged.match_type || !merged.pattern) {
      return res.status(400).json({ error: 'name, matchType, pattern are required' });
    }
    autoReply.update(id, merged);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});
app.delete('/api/auto-reply/:id', (req, res) => {
  const id = Number(req.params.id);
  autoReply.delete(id);
  res.json({ ok: true });
});

io.on('connection', (socket) => {
  logger.info('Socket connected');
  socket.on('join_session', ({ sessionId }) => {
    if (!sessionId) return;
    socket.join(getRoom(sessionId));
    const state = sessions.get(sessionId);
    socket.emit('wa_ready', { sessionId, ready: Boolean(state?.isReady) });
    // If a fresh QR was recently generated, push it immediately for faster linking
    if (state && state.lastQr && (Date.now() - state.lastQrAt) < 60000) {
      socket.emit('wa_qr', { sessionId, qr: state.lastQr });
    }
  });
  // Serve system variables preview (client may request real-time)
  socket.on('sys_vars_now', () => {
    const now = new Date();
    const pad2 = (n) => String(n).padStart(2, '0');
    const fmtDate = `${now.getFullYear()}-${pad2(now.getMonth()+1)}-${pad2(now.getDate())}`;
    const fmtTime = `${pad2(now.getHours())}:${pad2(now.getMinutes())}`;
    socket.emit('sys_vars_now', { date: fmtDate, time: fmtTime, datetime: `${fmtDate} ${fmtTime}` });
  });
});

server.listen(PORT, () => {
  logger.info(`Server listening on http://localhost:${PORT}`);
  
  // Load user tags
  loadUserTagsFromFile();
  
  // Start cron scheduler for flow triggers
  startCronScheduler();
  logger.info('Cron scheduler started for flow triggers');
  
  // Start workers for any session that becomes ready
  setInterval(() => {
    for (const [sid, st] of sessions.entries()) {
      if (st.isReady) {
        const worker = workers.get(sid);
        const pendingCount = queue.pendingCount(sid);
        
        // Start worker if not running and there are pending jobs
        if (pendingCount > 0 && (!worker || !worker.running)) {
          logger.info({ sessionId: sid, pendingCount }, 'Auto-starting worker for pending jobs');
          // Remove existing worker if it exists but is not running
          if (worker && !worker.running) {
            workers.delete(sid);
          }
          startWorker(sid);
        }
      }
    }
  }, 1000);
  
  // Handle timeouts for waiting flows
  setInterval(() => {
    if (!global.waitingFlows) return;
    
    const now = Date.now();
    for (const [phone, flowState] of global.waitingFlows.entries()) {
      if (flowState.timeout && (now - flowState.timestamp) > flowState.timeout) {
        // Timeout reached, continue with timeout node
        const flow = savedFlows.get(flowState.flowId);
        if (flow && flowState.timeoutNodeId) {
          const byId = new Map();
          for (const n of flow.nodes) byId.set(n.id, n);
          const timeoutNode = byId.get(flowState.timeoutNodeId);
          
          if (timeoutNode) {
            logger.info({ phone, flowId: flow.id, timeoutNodeId: flowState.timeoutNodeId }, 'Flow timeout reached, continuing with timeout node');
            continueFlowExecution(flow, timeoutNode, flowState.context, flowState.context.sessionId);
          }
        }
        
        // Remove from waiting flows
        global.waitingFlows.delete(phone);
      }
    }
  }, 5000); // Check every 5 seconds
  // Reinitialize known sessions directories on boot to show in UI
  try {
    const authBase = path.resolve('.wwebjs_auth');
    if (fs.existsSync(authBase)) {
      const entries = fs.readdirSync(authBase, { withFileTypes: true });
      for (const e of entries) {
        if (!e.isDirectory()) continue;
        const name = e.name.replace(/^session-/, '');
        if (name.startsWith('whats-tool-')) {
          const sessionId = name.replace('whats-tool-', '');
          if (!sessions.has(sessionId)) {
            const st = ensureSession(sessionId);
            try { st.client.initialize(); } catch {}
          }
        }
      }
    }
  } catch (err) {
    logger.warn({ err: String(err) }, 'Failed to pre-load sessions');
  }
});

// Graceful shutdown to avoid profile corruption
async function gracefulShutdown() {
  try {
    logger.info('Shutting down gracefully...');
    for (const [sid, st] of sessions.entries()) {
      try { await st.client?.logout(); } catch {}
      try { await st.client?.destroy(); } catch {}
    }
    process.exit(0);
  } catch {
    process.exit(1);
  }
}
process.on('SIGINT', gracefulShutdown);
process.on('SIGTERM', gracefulShutdown);


